# Paper 3: OwnGoal CTL2 (final authorship-confound replication): RESULTS & FINAL DECISION
Run 2026-10-05, about 01:20–01:32 IST. Files: `owngoal_pilot/ctl2/`.

## A. Freeze record
- `CTL2_PREREG.md` and `CTL2_SHA256.txt` were written before any model call. They cover the generator, 480 items, both validators, the analysis (ctl_analyze.py, byte-identical to ctl/), the decision script ctl2_decide.py with the frozen F/K/I/PURE hierarchy, the runner, the model config, and the pilot files (hashes unchanged).
- The decision hierarchy was plumbing-tested; all four branches fired as intended.

## B. Contradiction audit (V-CONFLICT): PASS
- 0 contradictions.
- In every OTHER move step, the user turn reports Operator B's change and the assistant turn is exactly "Step s: I make no u1 change."
- 0 assistant turns contain global-state phrases (hold / unchanged / no change / remain / stay / kept / constant).

## C. Matched-quadruplet validation: PASS
- 120 quadruplets, 0 problems; ideal observer 1.000.
- Versus ctl/: identical item ids, physics and messages, except the repaired no-action turns (0 other differences).

## D. Execution integrity
- 1,008 records (480 Qwen, 480 Mistral, 48 gpt-4.1) in 10.6 min.
- 6 OpenAI 429s were retried, leaving 0 errors.
- 1 parse failure (a Qwen empty answer, counted as incorrect per the frozen rule).
- results sha256 6ac11877…9415cd1. Correctness was not inspected during the run. Keys were deleted after the run.

## E. Four cell accuracies: own-move items (95% CI)
| Cell | Qwen3-14B | Mistral-Small-24B | gpt-4.1 (n = 6) |
|---|---|---|---|
| A OWN / EARLIER | 0.08 [0.02, 0.17] | 0.00 | 0.00 |
| B OWN / RECENT | 0.32 [0.20, 0.43] | 0.00 | 0.67 |
| C OTHER / EARLIER | 0.25 [0.15, 0.37] | 0.00 | 0.50 |
| D OTHER / RECENT | 0.42 [0.30, 0.55] | 0.08 [0.02, 0.17] | 1.00 |

## F. Contrasts (pp, matched bootstrap)
| | Qwen3-14B | Mistral-Small-24B |
|---|---|---|
| C1 = C − A (authorship @ EARLIER) | **+16.7 [+5.0, +30.0]** | **0.0 [0, 0]** |
| C2 = D − B (authorship @ RECENT) | +10.0 [−5.0, +25.0] | +8.3 [+1.7, +16.7] |
| C3 = B − A (recency within OWN) | **+23.3 [+10.0, +36.7]** | 0.0 |
| C4 = D − C (recency within OTHER) | +16.7 [+1.7, +31.7] | +8.3 [+1.7, +16.7] |

## G. Marginal authorship Δ_A
Qwen **+13.3 [+3.3, +23.3]**; Mistral +4.2 [+0.8, +8.3].

## H. Marginal position Δ_P
Qwen **+20.0 [+9.2, +30.8]**; Mistral +4.2 [+0.8, +8.3].

## I. Interaction Δ_AP
Qwen +6.7 [−11.7, +25.0] (none); Mistral −8.3 [−16.7, −1.7] (small).

## J. Exogenous controls
0.95–1.00 in every cell for every model, so prompt generation is sound. The near-ceiling "external" answers confirm the models' strong default.

## K. Confidence
Wrong attributions are still made with high confidence: Mistral 78–85; Qwen 69–75 when wrong vs 61–69 when correct (more confident when wrong, as in ctl/).

## L. Belief-to-action propagation (replicates)
| | P(fault_response \| external belief) | P(fault_response \| move-caused belief) |
|---|---|---|
| Qwen | 0.45–0.72 | 0.00–0.05 |
| Mistral | 0.93–1.00 | 0.00 |
| gpt-4.1 | 0.83–1.00 | 0.00 |

## M. Comparison with the first control (ctl/ → ctl2/; only the no-action wording changed)
| | Qwen ctl → ctl2 | Mistral ctl → ctl2 |
|---|---|---|
| C1 (authorship @ EARLIER) | −3.3 → **+16.7** | 0.0 → 0.0 |
| C3 (recency within OWN) | +6.7 → **+23.3** | 0.0 → 0.0 |
| C4 (recency within OTHER) | +23.3 → +16.7 | +23.3 → **+8.3** |
| OTHER / RECENT accuracy | 0.40 → 0.42 | 0.23 → **0.08** |

- A one-phrase wording change, which should be causally irrelevant, reversed Qwen's authorship-at-EARLIER sign and removed the interaction pattern (own reminders now help Qwen).
- It also cut Mistral's only working cell by two-thirds.
- **The authorship and interaction effects are not stable under a minimal, semantics-preserving prompt repair.**

## N. Frozen decision rule that fired
**"AUTHORSHIP MAIN EFFECT NOT ESTABLISHED (model-inconsistent C1; F-path failed); NEITHER AUTHORSHIP NOR DIFFERENTIAL INTERACTION SURVIVES" → ceiling KILL → STOP / KILL.**
- **F-path:** Qwen F1/F2/F3 = ✓✓✓; Mistral ✗✗✗. Not both, so not restored.
- **K-AUTH:** Mistral ✓, Qwen ✗ (C1 significant). This is model-inconsistent, which falls under the same downstream branch by the frozen rule.
- **Interaction (I1 ∧ I2 in both):** Qwen I1 ✓ but I2 ✗ (an own reminder now helps, +23 pp); Mistral I1 ✗ (C4 +8 < 15). Fails.
- **PURE recency (in both):** fails. Mistral has no recency effect within OWN; Qwen's C1 is not null.

## O. Exact surviving proposition
None at the paper level. The only robust observations across pilot, ctl and ctl2 are:
- in a multi-turn supervisory dialogue, these models strongly default to "external disturbance/fault" for deviations caused by a recorded u1 move, whoever made it, with high confidence;
- that wrong belief drives fault-response recommendations.

These are descriptive regularities, not a controlled mechanism.

## P. Claims permanently withdrawn
1. "LLM supervisory agents discount their own actions": the main effect (OwnGoal core) is withdrawn.
2. The pilot's 31–38 pp own-vs-third-party gap as an authorship effect (it was mainly presentation).
3. "Own-action misattribution grows with dead time" (withdrawn after the pilot).
4. "A recent reminder helps another operator's action more than the agent's own" (the ctl interaction did not replicate under repair).

## Q. Paper ceiling
**KILL** (the controlled result is weak, model-inconsistent and unstable under a minimal wording repair).

## R. Venue implication
None. No submission is warranted from OwnGoal.

## S. Final OwnGoal decision
**STOP / KILL.** No further experiments, per the stopping rule (no additional wording, format or model rescue).

### Note for the Orchestrator (not a rescue)
- The instability itself is the most striking observation: a semantics-preserving change to the no-action turn moved effects by 10–20 pp.
- This is consistent with known prompt-sensitivity literature, so by the project's own novelty standard it is not a Paper 3 candidate.
- The complete preregistered chain (05 → 10), with code, frozen items and results, is archived in `owngoal_pilot/` for reference or for a methods appendix elsewhere.
