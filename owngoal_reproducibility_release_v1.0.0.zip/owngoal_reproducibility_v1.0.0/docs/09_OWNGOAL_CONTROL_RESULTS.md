# Paper 3: OwnGoal confound-resolution control (2×2 authorship × position): RESULTS
Run 2026-10-05, about 01:00–01:10 IST. Files: `owngoal_pilot/ctl/` (freeze, items, results, report, logs).

## A. Freeze record
- `CTL_PREREG.md` and `CTL_SHA256.txt` were written **before any model call**. They cover the generator, 480 control items, validator, analysis script with frozen thresholds and decision order, runner, model config, and the reused pilot files (owngoal.py / analyze.py / run_models_parallel.py hashes unchanged from the pilot freeze).
- Decision logic was plumbing-tested with four pseudo-models (authorship / position / mixed / null). Each fired its intended branch.

## B. Matched-quadruplet validation: PASS
- 60 situations (10 per d×N cell) × 2 causes × 4 cells = 480 items, giving 120 quadruplets with **0 problems**.
- Plant history (y, u, disturbance, probe time, label, d, N, k, seed) is identical within every quadruplet.
- The only differing messages are the move-step user/assistant turns and the final message.
- y is identical across cause twins; ideal observer 1.000.

## C. Execution record
- Models: Qwen/Qwen3-14B and Mistral-Small-24B-Instruct-2501 (DeepInfra), each with 480 calls; gpt-4.1-2025-04-14, 48 calls (10% slice, descriptive).
- Smoke test ALL PASS. 1,008 records in 9.1 min.
- 4 transport errors (OpenAI 429) were retried at 3 workers, leaving 0 errors and 0 parse failures.
- results sha256 b56bb66d…ceace4b5. Correctness was not inspected during execution. Temporary keys were deleted after the run.

## D. Raw cell accuracies: own-move (endogenous) items, 95% bootstrap CI
| Cell | Qwen3-14B | Mistral-Small-24B | gpt-4.1 (n = 6, descriptive) |
|---|---|---|---|
| A OWN / EARLIER | 0.20 [0.10, 0.30] | 0.00 [0.00, 0.00] | 0.17 |
| B OWN / RECENT | 0.27 [0.15, 0.38] | 0.00 [0.00, 0.00] | 0.67 |
| C OTHER / EARLIER | 0.17 [0.08, 0.27] | 0.00 [0.00, 0.00] | 0.50 |
| D OTHER / RECENT | 0.40 [0.28, 0.53] | 0.23 [0.13, 0.35] | 1.00 |

Exogenous twins: 0.98–1.00 in every cell for every model, so the models default to "external".

## E. Marginal authorship effect Δ_A = OTHER − OWN
- Qwen **+5.0 pp [−2.5, +12.5]**.
- Mistral **+11.7 pp [+6.7, +17.5]**.

## F. Marginal position effect Δ_P = RECENT − EARLIER
- Qwen **+15.0 pp [+6.7, +24.2]**.
- Mistral **+11.7 pp [+6.7, +17.5]**.

## G. Interaction Δ_AP = (C − A) − (D − B)
- Qwen −16.7 pp [−33.3, 0.0].
- Mistral **−23.3 pp [−35.0, −13.3]**.
- In both models the authorship gap exists only at RECENT.

## H. Four decisive contrasts
| Contrast | Qwen3-14B | Mistral-Small-24B |
|---|---|---|
| C1 authorship @ EARLIER (C − A) | **−3.3 [−11.7, +5.0]** (null) | **0.0 [0, 0]** (null: both at floor) |
| C2 authorship @ RECENT (D − B) | +13.3 [0.0, +26.7] (CI touches 0) | **+23.3 [+13.3, +35.0]** |
| C3 recency within OWN (B − A) | +6.7 [−5.0, +18.3] (n.s.) | **0.0** (a reminder of its own move does nothing) |
| C4 recency within OTHER (D − C) | **+23.3 [+11.7, +36.7]** | **+23.3 [+13.3, +35.0]** |

## I. Results by model
- **Qwen3-14B:**
  - No authorship main effect.
  - Position effect present, but only for the operator's move: a recent reminder of an operator's move helps (+23 pp), while a recent reminder of its own move does not (+7 pp, n.s.).
- **Mistral-Small-24B:**
  - Total failure in three cells.
  - The single non-zero cell is OTHER/RECENT (0.23), mostly via "both" answers (41/60).
  - Its own move is never credited, whether in an earlier turn or restated in the final message.
- **gpt-4.1** (6 situations): both main effects in the same direction (Δ_A +33, Δ_P +50). Descriptive only.

## J. Confidence analysis
- Wrong attributions are made with high confidence: Mistral 77–85 on wrong answers; Qwen 70–77 on wrong vs 65–68 on correct.
- **Qwen is more confident when wrong than when right.**
- Brier is worst in OWN/EARLIER (Qwen 0.50, Mistral 0.72) and best in OTHER/RECENT (0.35 / 0.47).

## K. Phantom-correction / action analysis
**Belief → action propagation is clean in both models:**
- P(fault_response | "external" belief) = 0.56–0.60 for Qwen and 0.80–1.00 for Mistral.
- P(fault_response | "my/the move" belief) = 0.00–0.08.

Fault-response rate on own-move items, by cell:
| Model | OWN / EARLIER | OTHER / RECENT |
|---|---|---|
| Qwen | 0.47 | 0.30 |
| Mistral | 1.00 | 0.10 |

The causal-belief error is the driver of the action error.

## L. Plant-factor sensitivity (secondary)
- Δ_A by dead time: Qwen +7.5 / +2.5 / +5.0 (d = 0 / 1 / 3, all CIs ∋ 0); Mistral +7.5 / +25.0 / +2.5.
- No consistent dead-time pattern, consistent with the pilot.

## M. Interpretation rule that fired
**"UNRESOLVED (no pre-data rule fully satisfied) → ONE FURTHER CONTROL."**
- Authorship path (A1 ∧ A2 ∧ A3 in both): **No.** Mistral passes A1–A3; Qwen fails all three (Δ_A n.s.; C2 CI touches 0; A3 share 0.25 < 1/3).
- Position-only: **No.** C3 is not significant in either model, and C2 is not null.
- Null: **No.** Δ_P is significant in both.
- Mixed: **No**, because the authorship path did not hold in both.

### Two facts the rules do not capture, recorded here
1. **The pilot's large gap was mostly a presentation effect.**
   - When the operator's move is placed in an earlier turn at the same position (cell C), the models fail as badly as with their own move: C1 is about 0 in both.
   - Even the best cell here (D: 0.40 / 0.23) is far below the pilot's single-message third-party framing (0.75 / 0.77). Wrapping the episode in a multi-turn supervisory dialogue is what makes both models default to "external".
   - **The hostile-reviewer recency/format explanation is substantially correct for the pilot's headline 31–38 pp gap.**
2. **A residual, narrower authorship asymmetry exists.**
   - A recent restatement rescues the operator's move (C4 +23 pp in both models) but not the model's own move (C3 +7 n.s. / 0).
   - This is an authorship × position interaction, not an authorship main effect.

### Design threat found after the run (declared, not used to rescue anything)
- In OTHER cells, the assistant turn at the move step reads "hold u1 (no change)". It is meant as "I made no change", but it can be read as "u1 was not changed", contradicting Operator B's move.
- This would bias **against** the OTHER cells. So C2/C4 (OTHER better) are conservative, but C1 ≈ 0 could partly be an artefact of the contradiction.
- This is the main reason the further control is warranted.

## N. Exact surviving mechanism
> In a multi-turn supervisory dialogue, LLM agents default to blaming an external fault for a deviation caused by a recorded u1 move, largely regardless of who made the move when it sits in an earlier turn. A recent restatement of the move restores correct attribution for another operator's move but not, or much less, for the agent's own move. The wrong belief propagates directly into fault-response actions.

What is **withdrawn**:
- "Agents discount their own actions" as a main effect at matched position (C1 null in both).
- The pilot's 31–38 pp figure as an authorship effect.

## O. Paper ceiling
**COMPACT ARTICLE (provisional).**
- The surviving claim is an interaction plus a strong context-integration failure, with clean belief→action propagation and exact labels.
- That is publishable as a compact empirical article, but not as the originally framed full "OwnGoal" article unless the further control shows C1 > 0 once the wording conflict is removed.

## P. Venue implication
- EAAI is unchanged as the primary venue: empirical AI-in-engineering evaluation, compact format acceptable.
- C&CE becomes less likely: the core finding is now more about LLM context handling than process-systems engineering.

## Q. Next action
**ONE FURTHER CONTROL**, as the frozen rule dictates. Narrow scope:
- Same 480 items and models, a re-run of the 2×2.
- Single change: the assistant's move-step turn in OTHER cells becomes the agent-only statement "Step s: I make no u1 change." (and the same wording for all non-move hold turns in every cell, to keep cells parallel).
- Freeze the same decision rules.
- Cost and time: about 1,000 calls, under US$1, about 10 minutes of runtime.
- If C1 stays ≈ 0 in both models: authorship at matched position is dead, so finalise the compact-paper design around the interaction and the dialogue-format default.
- If C1 ≥ 10 pp in both: authorship is restored as a main effect, so the full study is reconsidered.
