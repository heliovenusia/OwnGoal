# Paper 3: OwnGoal micro-pilot report (2026-10-04)

Package: `owngoal_pilot/` (code, 1,140 frozen items, hashes, lock file). Design: `05_OWNGOAL_VERDICT.md` §Q–R. Pre-data operationalisations: `owngoal_pilot/PREREG_LOCK.md`.

## A. Status
**PILOT NOT EXECUTED: NO MODEL DATA.** The preregistered model runs could not be performed in this session. Every model-independent component was built, frozen and passed its checks. **No kill criterion was evaluated, so none fired.** OwnGoal's verdict stays **NARROW / untested**.

## B. Preregistration adherence
Factors, levels, item counts, prompts, baselines, thresholds and KC logic are implemented as written in §Q–R. Nothing was changed after seeing results, because no model results exist. The open details listed in PREREG_LOCK.md were fixed before any model output and are hashed in SHA256SUMS.txt.

## C. Execution blocker
| Resource | Cloud workspace | Linked computer (VM) |
|---|---|---|
| GPU | none | none |
| CPU / RAM | 2 / 7 GB | 2 / 3 GB |
| Local LLM server (Ollama) | none | none reachable |
| Model weights (Hugging Face) | blocked by allowlist | blocked |
| API providers (OpenRouter, Together, Groq) | blocked | blocked |
| API keys | none configured | none |

A 14–24B model cannot be loaded in 3–7 GB of RAM on 2 cores. An 8B model would need about 2–3 min per call on CPU (≈ 50+ h per model). Substituting tiny models would change the preregistered model set, so **no substitution was made**. The system used to construct the benchmark was not included as a test subject because it had access to the item labels.

## D. What was built (frozen)
- `owngoal.py`: plant, minimal-pair generator, 2×2 counterfactual labeller, prompt builder (3 authorship framings + hint arm), ideal and log-blind observers.
- `items.jsonl`: 1,140 items (1,080 core + 60 both).
- `run_models.py`: resumable runner for any OpenAI-compatible endpoint, temperature 0.
- `analyze.py`: preregistered metrics and KC1–KC5 evaluator with bootstrap CIs.
- `integrity_check.py`: the model-free gate.
- `test_pipeline.py`: plumbing test with pseudo-models.
- `sample_prompts.md`: audit view of the frozen prompts.

## E. Item set and retention
- Labels: 360 endogenous, 360 exogenous, 60 mixed, 360 below-noise (excluded).
- 780 items retained.
- Below-noise exclusions are exactly the cells where the probe lag precedes onset (k ≤ d): (1,2,1), (1,8,1), (3,2,1), (3,8,1). Every d×N cell keeps ≥ 60 retained items per authorship × cause set, so KC1/KC4 "every cell" remains evaluable.
- Within-pair y identity: max difference 0.0 (exact).
- Max interaction term: 1.3e−15 (linear plant, as expected).

## F. Integrity gate (preregistered, model-free): PASS
| Observer | Core (n = 240 unique) | Both (n = 20 unique) | Overall |
|---|---|---|---|
| Ideal (true G + action log) | **0.996** | 1.000 | **0.996 ≥ 0.98: PASS** |
| Log-blind | **0.496** (≈ 50%, as designed) | 0.000 | – |

So the retained items are decidable from the agent's information set, and they require the log.

## G. Evaluator validation (plumbing only, not data)
Deterministic pseudo-models were fed through `analyze.py`. Each triggered exactly its intended criteria:
- all-ideal fires KC1 + KC4 (+ KC2);
- all-log-blind fires KC3 (+ KC2);
- synthetic self-blind (log ignored only for own-framed items with d ≥ 1) fires KC5 (+ KC4).

## H. Model results
**None.** No LLM call was made.

## I. KC1 (no phenomenon): **NOT EVALUATED / not fired**
## J. KC2 (not self-specific, not dynamic): **NOT EVALUATED / not fired**
## K. KC3 (generic context blindness): **NOT EVALUATED / not fired**
## L. KC4 (trivial fix): **NOT EVALUATED / not fired**
## M. KC5 (proceed): **NOT EVALUATED / not fired**

## N. Secondary metrics (both items, Brier, phantom correction)
Not available.

## O. Surviving proposition
Unchanged from 05 §O and **untested**.

## P. Pilot authorization status
Still authorized; execution is pending compute. One of the following is needed:
- (a) a machine with a GPU (≥ 24 GB VRAM for mistral-small:24b; ≥ 12 GB for qwen3:14b) running Ollama, linked to this session; or
- (b) an API key for a provider serving these open weights (e.g. OpenRouter / Together), with that host added to the session's network allowlist; or
- (c) running the frozen package yourself on any such machine and sending back `results.jsonl`.

For (c), I run `analyze.py` unchanged against the frozen hashes.

## Q. Exact run procedure (unchanged design)
```
cd owngoal_pilot
sha256sum -c SHA256SUMS.txt          # must pass; abort if not
python integrity_check.py            # must print PASS
# edit models.json ONLY for endpoint/model-serving names + frontier slot
python run_models.py models.json     # ~4.3k calls: 3 × (1,140 + ~285 hint) + ~114 frontier
python analyze.py results.jsonl analysis_report.json
```
Expected cost: about 1–2 days on a single 24 GB GPU, or a few US dollars via an open-weights API.

## R. Kill-criteria status (explicit)
| Criterion | Fired? | Reason |
|---|---|---|
| KC1 no phenomenon → KILL | **No (not evaluable)** | no model outputs |
| KC2 not self-specific & not dynamic → KILL | **No (not evaluable)** | no model outputs |
| KC3 generic context blindness → KILL/PIVOT | **No (not evaluable)** | no model outputs |
| KC4 trivial fix → DOWNGRADE | **No (not evaluable)** | no model outputs |
| KC5 proceed threshold | **No (not evaluable)** | no model outputs |
| Integrity gate (ideal ≥ 98%) | **PASSED (0.996)** | model-free, evaluated |
