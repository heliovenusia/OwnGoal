# Paper 3: OwnGoal micro-pilot RESULTS (run 2026-10-04 23:25 → 2026-10-05 00:08 IST)

Data: `owngoal_pilot/run/` (results.jsonl sha256 78603278…7f53; analysis_report.json; EXECUTION_RECORD.md; run.log).
Design: 05 §Q–R (frozen). Execution: 07 + PATCH_NOTE.md (parallel runner, verified identical requests).

## A. Verdict
**KC5 fired (PROCEED). KC1, KC2, KC3 and KC4 did not fire.**
- The self-attribution failure is real, large, and present in 2 of 2 functional open models (plus the descriptive frontier model).
- Two of the preregistered claims did **not** hold:
  1. no dependence on dead time in own-framed items;
  2. the "self-specific" interpretation is confounded with *where* the information sits in the transcript.
- **Status: NARROW → SURVIVES, re-narrowed (see O).**

## B. Execution summary
- 4,386 calls: 3 open models × 1,420 (1,140 base + 280 hint) + 126 frontier.
- Route: DeepInfra (Qwen/Qwen3-14B; meta-llama/Meta-Llama-3.1-8B-Instruct, served as "-Turbo"; mistralai/Mistral-Small-24B-Instruct-2501) and OpenAI gpt-4.1-2025-04-14 (frontier).
- Wall time about 40 min. Transport errors: 33 (all frontier HTTP 429), all retried successfully.
- Frozen hashes OK and integrity gate PASS (0.996) before the run.

## C. Preregistration adherence
- Items, factors, prompts, thresholds and KC logic are unchanged.
- Declared execution items, each recorded **before** data:
  - parallel runner (identical requests, verified);
  - DeepInfra/OpenAI serving;
  - frontier selection rule (gpt-5.5 and gpt-5.4 rejected the frozen `max_tokens` parameter, so gpt-4.1 was used);
  - the Llama "-Turbo" alias.
- The only post-hoc analyses are the answer-distribution breakdowns in F and I. They are descriptive and change no KC.

## D. Data quality
- Parse failures: Qwen 0.14%, Llama 0.07%, Mistral 0%, frontier 0%.
- Qwen3 thinking was active (reasoning returned in a separate field).
- **Llama-3.1-8B is a degenerate responder:** it answers "both" on ~90% of all items regardless of cause or framing (core accuracy ≈ 0–25%). It formally satisfies KC5 but carries little information, so the substantive conclusions rest on Qwen3-14B and Mistral-Small-24B.

## E. Primary result: authorship gap (retained core items, paired bootstrap 10k)
| Model | Gap = acc(third_party) − acc(own) | 95% CI | KC5 gap leg (≥10 pp, CI > 0) |
|---|---|---|---|
| Qwen3-14B | **+30.8 pp** | [24.6, 37.1] | ✓ |
| Mistral-Small-24B | **+37.5 pp** | [31.2, 44.2] | ✓ |
| Llama-3.1-8B | +16.3 pp | [11.7, 21.2] | ✓ (degenerate model) |
| gpt-4.1 (frontier, 10% slice, descriptive) | no paired items in the slice; see K | – | – |

## F. Error structure: what the models answer when the deviation was caused by the u1 move
Share answering **"external_disturbance_or_fault"** on own-move items (base arm):

| | own framing (move in its own earlier turns) | third_party (operator's move, final message) | neutral_log (u1 column) |
|---|---|---|---|
| Qwen3-14B | **0.85** | 0.21 | 0.26 |
| Mistral-Small-24B | **1.00** | 0.03 | 0.43 |
| gpt-4.1 (n = 9/17/15) | **0.78** | 0.41 | 0.27 |

- On exogenous items, every functional model answers "external" ≈ 100% in every framing.
- So the own-framing failure is **one-directional**: the model's own move is dismissed and the deviation is blamed on an external fault. This is exactly the OwnGoal error, not general noise.
- **Phantom correction** (fault_response on endogenous items):
  - Qwen: own 0.48 vs third_party 0.14;
  - **Mistral: own 0.97 vs third_party 0.03.**
- So the misattribution propagates into the recommended action.

## G. Dynamics (d = θ/Δt, N = t_s/Δt)
- **Own framing: flat.**
  - d-slope: Qwen −0.039 [−0.090, 0.012]; Mistral 0.000 [−0.052, 0.052].
  - Drop d0→d3: Qwen +11.7 pp [−3.3, 26.7]; Mistral 0.0 pp. The KC5 drop leg was met by no model.
  - Mistral sits at exactly 0.50 in every own cell: it always answers "external".
- The failure is already saturated at d = 0, so the onset-invisibility mechanism is **not needed** to produce it.
- In the third_party/neutral framings, accuracy does fall at d ≥ 1 with N = 2 (Qwen third_party: 0.93 → 0.65 → 0.60). Dynamics matter only once the move is actually attended to.
- **The preregistered "grows with dead time" clause of the proposition is NOT supported.**

## H. Minimal-pair flip at d = 0, N = 2 (KC3)
- Flip rate: Qwen 0.67 [0.57, 0.77]; Mistral 0.67 [0.57, 0.77]; Llama 0.29.
- KC3 requires < 50% in all three models, so it did **not fire**.
- The flips occur in the third_party/neutral framings, not in the own framing. The models do use logs, just not their own transcript.

## I. Hint arm (one-line forward model: gain, θ, τ; 25% slice)
| Own-move items, own framing | base | hint |
|---|---|---|
| Qwen3-14B correct | 0.13 | **0.61** |
| Mistral-Small-24B correct | 0.00 | **0.04** |

- KC4 (≥ 90% in every cell, every model) did not fire.
- **Mitigation dissociation:** the forward model partly rescues Qwen but not Mistral. In the hint arm, Mistral answers third_party/neutral own-move items 100% correctly but own-framed ones 4%. The self gap survives the forward model.

## J. Secondary metrics
- Brier: Qwen 0.18, Mistral 0.22, Llama 0.56.
- "Both" items (move + equal disturbance): Qwen 0.05, Mistral 0.20, Llama 0.98 (an artefact of always answering "both").
- No model handles superposed causes.

## K. Frontier (gpt-4.1, descriptive, small n)
Same direction: own-framed own-move items are blamed on an external cause 78% of the time (n = 9), vs 41% third_party and 27% neutral_log. Exogenous items are 100% correct. This is consistent but not inferential.

## L. Threats to interpretation (must be addressed before the claim is publishable)
1. **Authorship × position/format confound (critical).**
   - In the own framing the move lives in an *earlier assistant turn* of a 23-message dialogue.
   - In third_party/neutral it sits *in the final user message* next to the question.
   - The gap may therefore be "information in earlier turns is under-weighted" rather than "self-authored actions are discounted".
   - The preregistered design did not separate the two.
2. **Single prompt template and plant story** (CSTR feed/temperature).
3. **One run at temperature 0; provider precision** (fp8/"Turbo"). These are unlikely to produce a 30–37 pp effect, but are unreplicated.
4. **Llama degeneracy:** effectively n = 2 functional open families.

## M. Hostile desk-editor sentence (updated)
> "The models simply ignore information placed in earlier chat turns; 'self-attribution' is a relabelled long-context recency effect."

Section L.1 is exactly this objection, and the current data cannot refute it.

## N. Kill-criteria status (explicit)
| Criterion | Fired? | Evidence |
|---|---|---|
| KC1 no phenomenon (own acc ≥ 90% in all cells, all models) | **No** | own accuracy 0.00–0.65 |
| KC2 gap < 5 pp in all models **and** d-slope CI ∋ 0 | **No** | gaps +16 to +38 pp, all CIs > 0 (the d-slope CIs do include 0) |
| KC3 flip rate < 50% at d0/N2 in all models | **No** | Qwen 0.67, Mistral 0.67 (Llama 0.29) |
| KC4 hint ≥ 90% in every cell, all models | **No** | Mistral hint cells 0.71–1.00 overall; own-framed own-move 0.04 |
| **KC5 PROCEED** (≥ 2/3 models: gap ≥ 10 pp or drop ≥ 15 pp, CI > 0) | **YES** | gap leg in 3/3 (2/2 functional); drop leg 0/3 |
| Integrity gate | PASS | 0.996 |

## O. Exact surviving proposition (re-narrowed by the data)
> On minimal pairs with identical observations, LLM supervisory agents attribute a deviation caused by a control move recorded in their **own prior turns** to an external fault far more often than when the identical move is reported in the current message (Qwen3-14B +31 pp, Mistral-Small-24B +38 pp), and they recommend a fault response accordingly. The failure is present already at zero dead time and is only partly mitigated by an explicit forward model.

Dropped: "grows with dead time" (not supported). Pending: whether the cause is *authorship* or *turn position* (L.1).

## P. Paper 3 status
- OwnGoal is now the only Paper 3 candidate with **positive preregistered empirical evidence**: a large, one-directional, action-propagating effect, with exact labels and an ideal-observer-verified item set.
- **Contribution ceiling right now:** a compact article if L.1 resolves toward position (reframed as a supervisory-agent context-integration failure, a weaker claim); a **full article** if L.1 resolves toward authorship, combined with the closed-loop phase.

## Q. Recommended next step (for the Orchestrator; not executed)
1. **Format-matched control micro-pilot (before the closed-loop phase).** This is a single new factor; same plant, items and metrics. Present the identical move as:
   - (i) own assistant turn (existing);
   - (ii) an operator's **user turn at the same position** in the dialogue;
   - (iii) own move restated in the final message ("Recall: at step k you increased u1 by …").

   Cost: about 2–3k calls, under US$1, about 30 min.
   - (i) ≪ (ii) ≈ (iii) means **authorship**: the full-article path.
   - (i) ≈ (ii) ≪ (iii) means **position**: compact or reframe.
2. Then the preregistered closed-loop phase and the blanking-cost arm, as KC5 authorises.
3. Replace or supplement Llama-3.1-8B (degenerate) only through a preregistered amendment before any further run.

## R. Pre-data kill criteria for the format-matched control (proposed; to be frozen by the Orchestrator)
- **KC-F1 (position, not self):** (ii) − (i) gap < 10 pp with CI ∋ 0 in both functional models → drop the "self" framing and reframe as turn-position integration failure (compact ceiling).
- **KC-F2 (authorship):** (ii) − (i) ≥ 15 pp with CI > 0 in both → authorship effect confirmed, so proceed to closed-loop.
- **KC-F3 (trivial restatement fix):** (iii) ≥ 90% in all cells → report as mitigation; not a kill on its own.
