# Paper 3: OwnGoal literature kill + control-theoretic audit: VERDICT (2026-10-04)

Evidence log: `04_owngoal_kill_log.md` (3 batches, ~30 items). The earlier search is in 01–03.

## Analysis notes (brief §§6–13)

### Boundary variables (§6–7)
For a linear(ised) plant sampled at the decision interval Δt, y_t = Σ_m g_m u_{t−m} + (disturbance terms). The number of past moves "alive" at decision t is the smallest M with tail ‖g_{m>M}‖ < ε. For FOPDT this is M_ε ≈ (θ + τ·ln(1/ε))/Δt, i.e. **settling time in decision intervals**. This is exactly the classical **step-response (DMC) model horizon N** expressed in samples.
- "Causal memory depth" **reduces to N = t_s/Δt**. Do not coin a new metric.
- The single ratio (θ+τ)/Δt from 03 **conflates two different mechanisms** and is withdrawn:
  1. **Onset invisibility**, governed by **d = θ/Δt** (dead time in decision intervals, the z^{-d} of the discrete model). For d ≥ 1 the agent's next decision sees *no* response to its move, so it either judges the move ineffective and repeats it, or later sees a response "from nowhere".
  2. **Superposition**, governed by **N = t_s/Δt** times the intervention rate, giving the per-decision count of unresolved moves **n_alive(t)**. The current deviation is a sum of several alive moves plus any disturbance.
- Per-item difficulty also depends on:
  - **self-share s_t** = |Δy_self| / (|Δy_self| + |Δy_exo|);
  - **SNR** = |Δy| / σ_v;
  - a structural factor: **shape similarity between disturbance and input paths** (G_d vs G_u). If G_d = G_u (input disturbance), shape cannot disambiguate and only the log can. If they differ, shape alone can.

### Counterfactual labels (§8–9)
- Fix all exogenous sequences (disturbance, fault, noise) by common random numbers. The unit of intervention is the **supervisor move**; regulatory PID loops are part of the plant, so their reaction to a move counts as the move's effect (correct).
- **Valid (deterministic): C1 = C3**, plant-only replay with focal move(s) set to "no change" and all other recorded supervisor moves held as executed. This is a *controlled direct effect* conditional on the realised history.
- **2×2 factorial per probe time** (4 sims): actual; agent-moves-removed; exo-removed; both-removed. This gives the self effect, the exo effect and the **interaction I** (non-additivity).
- Labels: endogenous-dominant if s_t ≥ 0.8, |I| ≤ 0.1·|Δy| and |Δy| ≥ 3σ_v; exogenous-dominant is the mirror; "interacting" if |I| is large; otherwise ambiguous.
- Thresholds are swept in a sensitivity analysis. Binary scoring is defensible **only** on the dominant subsets; interacting/ambiguous items are reported separately.
- **Invalid for labels: C2** (policy-level re-planning). It is stochastic and contains the LLM itself, and it answers "what would the whole episode have been", not "what caused this observation".
- **Missing piece added: an identifiability filter.** An ideal observer (Bayesian model comparison or Kalman with the true model plus the action log) must be able to decide the label from the *agent's own information set*. Items the ideal observer cannot resolve are excluded. Otherwise errors may be unavoidable rather than failures.

### Belief vs action (§10)
The agent must answer a forced-choice **cause classification** (own earlier move / external disturbance or fault / both / cannot determine) plus confidence, **before** recommending an action. Phantom correction (acting against a self-caused transient) is scored separately. Belief-probe designs are accepted practice (belief-based world-model papers), but **none probes self-vs-exogenous causal belief.**

### Matched static vs trajectory (§11), sharpened
The useful form is not "static vs interactive" but **causal-history minimal pairs**: *identical* observation windows (same noise seed; G_d = G_u, so an input disturbance of equal size and timing reproduces y exactly) whose correct cause flips with the history.
The **authorship contrast** is crossed with the minimal pairs: the causal move appears (a) as the agent's own earlier assistant turn, (b) as another operator's move reported by the user, or (c) as a neutral log row. If the attribution is right in (b)/(c) and wrong in (a) on the same state, that is a *self-specific* deficit, which "temporal reasoning is hard" does not predict. **No prior benchmark found with this matched design.**

### Mitigations (§12)
These are mechanism-mapped only:
- action-log emphasis tests attention to the "efference copy";
- a one-line expected-response statement (gain/θ/τ) tests whether a *forward model* is the missing object;
- a forward-simulation tool tests explicit counterfactual prediction.

EgoDyn-Bench's finding (explicit kinematics text fixes the failure) predicts the response-model arm may largely mitigate. If it does so cheaply, the paper's ceiling drops.

### Models (§13)
Precedents run 2 models (Rosenthal: DeepSeek-V4-Flash + Nemotron ablation) to 7 models (Yu et al.). **3 open families + 1 frontier spot-check** meets norms. Fixed temperature, ≥10 seeds per cell, bootstrap CIs (Rosenthal's 10k-resample standard).

---

## A. Verdict
**NARROW.**

## B. Operational Hallucination comparison
Yu, Carroll & Bentley (2607.18366) define operational hallucination as *persistent repetitive tool calls indicating flawed state perception* (livelock), in ≤10-turn Python/file tasks.
- They attribute it generically to "decoupling of reasoning context from execution state".
- They do **not** isolate state changes caused by the agent's own actions, do not evaluate self-vs-external attribution, do not ablate the history, use no counterfactual labels (only post-hoc log replay against monitors), and do not study timing.
- This is generic state desynchronisation. **K1 does not fire.**

## C. From Detection to Action comparison
Vyas, Gill, Markaj, Gehlhoff, Mercangöz (2606.28011) use a CSTR with 3 PID loops and faults fouling / pump_degrade / cool_stuck_closed.
- The pattern is **single intervention**: detect → plan → act → DPPT what-if (prospective, for the *proposed* move) → validate.
- They do not measure attribution. However, they **hard-code the OwnGoal safeguard**: *"After a validated corrective action is applied, expected transient deviations are not treated as new faults unless hard safety limits are violated."* So the hazard is practitioner-recognised and the blanking fix exists.
- OwnGoal must therefore (i) test agents *without* the blanking rule, and (ii) ideally show the blanking rule's cost: it masks a genuine fault that coincides with the post-action transient.

## D. ADMITBench comparison
ADMITBench (2608.03866) evaluates strictly **one proposed action record per case**.
- Actions do **not** alter subsequent observations. T4 checks predicted consequence over a profile-fixed horizon.
- Sequential evaluation is absent from scope but **not** stated as a gap. Future work is a cartridge registry and adversarial splits.
- There is no mention of advisory-induced deviations or multi-step attribution. OwnGoal fills an *unstated* temporal gap. It does not overlap, but it cannot be framed as answering their call.

**Additional close paper found:** Rosenthal (2607.27849, Jul 2026) runs a multi-cycle LLM distillation supervisor (12 cycles, forked-twin counterfactual gate, 800 runs).
- It reports a **"specification-abandonment attractor"**: the agent ratifies drift its own earlier proposals created. It also finds the agent is 16× worse than MPC on disturbance rejection.
- This is the **mirror failure** (self-caused drift *normalised*, not blamed on an external cause). It does not measure causal belief, labels or timescale.
- **"LLM supervisors get into trouble through their own earlier moves" is now shown.** Only the belief-level attribution claim remains open.

## E. General counterfactual-agent attribution comparison
- Minimal Repair Families (2608.29228) and CausalFlow (2605.25338) replay *agent outputs* (messages or steps) to find which agent step caused *task failure*. This is analyst-side blame assignment in symbolic, QA or code tasks, with no dynamics. CausalFlow explicitly cannot separate agent error from environment gaps.
- **Wilkins & Stathis (AAAI 2023)** is the true ancestor: reafferent vs exafferent separation via a counterfactual null action.
- **The claimed distinction is real but narrow.** Generic replay labels *which agent decision caused an outcome*. OwnGoal labels *the physical origin (u vs d) of an observation* and then tests the **agent's own belief** about it.
- The labelling technique is therefore **not** novel (null-action / controlled-direct-effect replay). The novelty must sit in the agent-belief test under delayed, superposed dynamics. **K2 does not fully fire, but P6 cannot be a claimed contribution.**

## F. Classical control/diagnosis ancestry
- Self-vs-external separation is **standard and solved by construction** in model-based FDI: residual generators use the known u (Chen & Patton; Gertler; Isermann), and unknown-input observers decouple d.
- Related classical work:
  - closed-loop identification confounding (Ljung; Forssell & Ljung);
  - fault masking by feedback;
  - consequential / state-based alarm suppression (ISA-18.2);
  - operator overcorrection under dead time (McRuer);
  - automation surprise and mode confusion (Sarter & Woods);
  - efference copy and forward models (von Holst; Wolpert).
- **Do not claim the causal problem is new.** Frame OwnGoal as testing whether LLM supervisors implicitly perform the known-input decoupling that a residual generator does by construction.

## G. Exact novelty residual
LLM supervisory agents have the efference copy (their own action log) but no explicit forward model. Whether they nonetheless separate self-caused from exogenous deviations, the way a residual generator does by construction, has not been measured. The residual contribution is (i) a belief-level test on causal-history minimal pairs with identical observations, (ii) a self-vs-third-party authorship contrast on the same state, and (iii) how this depends on dead time and settling horizon expressed in decision intervals.

## H. Boundary-variable verdict
Not one variable. Two classical dimensionless groups:
- **d = θ/Δt**, dead time in decision intervals, which governs onset invisibility;
- **N = t_s/Δt**, settling horizon in decision intervals (the DMC model horizon), which governs superposition. Its per-decision realisation is **n_alive** (unresolved moves).

Self-share s_t and SNR act as item-level covariates, and G_d ≈ G_u is a structural condition. "Causal memory depth" reduces to N and should not be coined. (θ+τ)/Δt is withdrawn. **K4 does not fire**, but the variables are classical and the boundary alone is near-K3.

## I. Counterfactual-label validity
**Replay CAN label:**
- the controlled direct effect of specified supervisor moves on y_t, holding the realised other moves and all exogenous sequences fixed (common random numbers; regulatory loops inside the plant);
- via a 2×2 factorial, the self effect, the exogenous effect and their interaction, giving endogenous-dominant / exogenous-dominant / interacting / ambiguous labels with swept thresholds;
- via an ideal-observer filter, whether the label was decidable from the agent's information set.

**Replay CANNOT label:**
- policy-level counterfactuals (what the agent would have done next);
- blame for the eventual episode outcome;
- binary cause where interaction is large or |Δy| sits within noise;
- anything under plant–model mismatch the agent was not told about.

**K5 does not fire** if binary scoring is restricted to dominant, identifiable items.

## J. Matched static-vs-trajectory proposition
**Generic static-vs-interactive: KNOWN.** Causal-history minimal pairs on identical observations: **PARTIALLY NOVEL**. Own-vs-third-party authorship contrast on the same state: **UNCLEAR → potentially NOVEL** (no prior found; the pilot decides).

## K. Novelty matrix
| | Proposition | Class |
|---|---|---|
| P1 | LLM control agents sometimes misattribute their own moves' consequences to faults | **OBVIOUS** (practitioners already engineer against it: FDA blanking rule; Rosenthal attractor is a sibling) |
| P2 | Persists with the full action log visible | **PARTIALLY NOVEL** |
| P3 | Depends systematically on response timescale / Δt | **PARTIALLY NOVEL**; directionally OBVIOUS (dead-time overcorrection is classical). Valuable only with the d/N mechanism split |
| P4 | Matched single-state diagnosis does not predict trajectory-context attribution on the same state | **PARTIALLY NOVEL** as minimal pairs; **UNCLEAR/potentially NOVEL** as the self-vs-third-party contrast |
| P5 | A forward response model fixes it better than an action-log reminder | **PARTIALLY NOVEL**; outcome plausibly predictable (EgoDyn-Bench analogue) |
| P6 | Counterfactual replay gives exact labels | **KNOWN** as technique (null-action reafference; controlled direct effect). The labelling protocol plus identifiability filter is a methods detail, not a headline |

Paperability needs **P2 + P4 (authorship contrast) + P3 mechanism split**. P1 alone and P6 alone are worthless.

## L. Venue audit
| | V1 Scope | V2 Contribution type | V3 Evidence depth | V4 Desk survivability |
|---|---|---|---|---|
| **C&CE** | ✓ PSE + LLM supervision in scope | ◐ benchmarks/tools exist in the PSE ecosystem (PC-Gym, TalkToAgent); journal-published LLM-evaluation precedent **not confirmed** in this pass | ◐ simulation-only is normal in PSE, but two FOPDT-class plants may look thin; add one PC-Gym-grade nonlinear unit | ◐ survives only if the abstract leads with FDI framing + minimal-pair result |
| **JPC** | ◐ LLM supervision is fringe | ✗/◐ favours methods/theory; no LLM-agent evaluation precedent found | ◐ | ✗ high risk of "not a control contribution" |
| **EAAI** | ✓ | ✓ empirical evaluation of AI in engineering is routine | ✓ | ✓ most forgiving; best expected-value choice |

**Recommendation:** EAAI primary, C&CE as stretch. JPC is not advised. K6 fires partially for JPC only.

## M. Strongest desk-reject sentence
> "The manuscript shows that LLMs reason poorly about delayed effects in textbook first-order-plus-dead-time simulations. This is an expected consequence of dead time, long known from human manual control and already handled in practice by post-action alarm blanking, and the counterfactual 'ground truth' is a standard controlled-direct-effect replay."

## N. What would overcome that rejection
At least two, ideally three, of the following:
1. **Authorship reversal on identical states.** Attribution is correct when the causal move is attributed to another operator or a log, and wrong when the move is the agent's own earlier turn. Dead time alone cannot predict this.
2. **Persistence with the explicit log + ideal-observer identifiability.** The errors are provably avoidable from the information given.
3. **Mechanism dissociation.** d drives errors at n_alive = 1 (invisibility), and N drives them at d = 0 (superposition). Two predictions, not one "delay is hard".
4. **Mitigation dissociation.** The log reminder fails while the forward-response statement works (or vice versa). This pins the missing object.
5. **Blanking cost.** The classical fix masks a genuine fault coinciding with the transient, which quantifies why the agent-side capability matters.

## O. Exact surviving proposition
> On causal-history minimal pairs (identical observation windows whose true cause is either a prior supervisor move or an equal exogenous disturbance), LLM supervisory agents misattribute deviations caused by their **own** earlier moves more often than the identical moves reported as another operator's, and this self-specific deficit grows with dead time measured in decision intervals despite the full action log being in context.

## P. Pilot authorization recommendation
**MICRO-PILOT AUTHORIZED.** The literature and theory audits cannot narrow further. The remaining uncertainty is purely empirical, and the pilot needs **no closed-loop LLM control**: moves are scripted and only beliefs are probed, so it is cheap.

## Q. Exact pilot design
- **Plant:** 2×2 linear system in Python (scipy). Agent-owned input u₁ (e.g. feed rate) affects monitored y₂ (e.g. reactor temperature) via FOPDT G₂₁(K, τ, θ). Input disturbance d enters y₂ through G_d = G₂₁, so minimal pairs reproduce y₂ *exactly*. Measurement noise σ_v; same seed within a pair.
- **Factors:**
  - cause ∈ {own move, exogenous disturbance}: the minimal pair;
  - authorship ∈ {own assistant turn, user-reported other operator, neutral log table};
  - d = θ/Δt ∈ {0, 1, 3};
  - N = t_s/Δt ∈ {2, 8};
  - probe lag k since the move ∈ {1, d+1, ⌈N/2⌉};
  - 10 seeds;
  - plus 60 "both" items (move + disturbance) for the interaction class, reported separately.
- **Probe (belief before action):**
  - Q1 cause ∈ {my/the earlier move · external disturbance/fault · both · cannot determine};
  - Q2 confidence 0–100;
  - Q3 recommended next move (scored for phantom correction).
  - JSON output, temperature 0, fixed prompt template; history window W = 12 decision steps shown as a table plus, for the "own" framing, prior assistant turns containing the move.
- **Baselines:** ideal observer (Bayesian model comparison with the true G and the log) must score ≈100% (identifiability check); log-blind observer ≈50% (shows the items need the log); a third-party framing control; a one-line expected-response hint arm (gain/θ/τ) on a 25% slice.
- **Models:** 3 open families (e.g. Qwen3-14B/32B, Llama-3.x-8B/70B, Mistral-Small) locally or via a cheap endpoint, plus one frontier model on a 10% slice.
- **Size:** 2 × 3 × 3 × 2 × 3 × 10 = 1,080 core items per model, about 3.5k calls plus slices. Single-turn calls; about 1–2 days on modest compute.
- **Deliverables:** accuracy by cell with bootstrap CIs, own-vs-third-party gap, d- and N-slopes, calibration (Q2), phantom-correction rate.

## R. Pre-data kill criteria (fixed before any data)
- **KC1 (no phenomenon):** own-authorship attribution accuracy ≥ 90% in every d×N cell for all 3 open models → **KILL**.
- **KC2 (not self-specific, not dynamic):** own-vs-third-party gap < 5 pp in all models **and** the d-slope CI includes 0 → **KILL**. This would leave only "temporal reasoning is hard" (K3).
- **KC3 (generic context blindness):** answers fail to flip within minimal pairs even at d = 0, N = 2 (the log is ignored regardless of dynamics) → **KILL or PIVOT** to a generic log-use finding (not OwnGoal).
- **KC4 (trivial fix):** the one-line expected-response hint restores ≥ 90% in every cell → downgrade to compact article / EAAI short.
- **KC5 (proceed threshold):** in ≥ 2 of 3 models, either an own-vs-third-party gap ≥ 10 pp or a d = 0→3 drop ≥ 15 pp, with bootstrap 95% CIs excluding 0 → **PROCEED** to the closed-loop phase (agent actually acts) and the blanking-cost arm.
- **Integrity:** ideal-observer accuracy < 98% on retained items means a labelling bug. Fix before reading any model results.
