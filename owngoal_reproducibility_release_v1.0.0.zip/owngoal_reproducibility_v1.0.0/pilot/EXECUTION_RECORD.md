# OwnGoal pilot: execution record

## Pre-run (written before the first data call)
1. Run start (IST): 2026-10-04 23:25:46
2. Executor: automated cloud workspace (Linux, Python 3.13.16), unattended. Temporary API credentials were stored privately and never printed.
3. Route C1: open models on DeepInfra (OpenAI-compatible); frontier on OpenAI. Runner: run_models_parallel.py (documented execution patch, PATCH_NOTE.md), workers = 24.
4. verify_hashes.py: ALL FROZEN FILES OK
5. integrity_check.py: PASS (ideal 0.996)
6. Frontier model: gpt-4.1-2025-04-14. Rule fixed before testing: the first of [gpt-5.5-2026-04-23, gpt-5.4-2026-03-05, gpt-4.1-2025-04-14] that accepts the frozen request format (temperature 0 + max_tokens). gpt-5.5 and gpt-5.4 returned HTTP 400 ("max_tokens not supported; use max_completion_tokens"); gpt-4.1 passed.
7. models_deepinfra.json SHA256: 00b495f923707a0153d661f4035f1f644388492b1207a7bad88182278b333014 (the placeholder substitution also altered the _note text; cosmetic only)
   Smoke test: ALL PASS.
   - qwen3-14b: echoed Qwen/Qwen3-14B; reasoning returned in a separate field (thinking ACTIVE; 137 completion tokens on the dummy prompt)
   - llama3.1-8b: requested meta-llama/Meta-Llama-3.1-8B-Instruct; provider echoed **meta-llama/Meta-Llama-3.1-8B-Instruct-Turbo** (DeepInfra's optimized deployment of the same checkpoint; precision may differ from bf16). Recorded as an anomaly before the run.
   - mistral-small-24b: echoed mistralai/Mistral-Small-24B-Instruct-2501; wraps JSON in a markdown fence (the frozen parser extracts it)
   - frontier: echoed gpt-4.1-2025-04-14

## Post-run
8. Run end (IST): 2026-10-05 00:07. Wall time about 40 min (main pass) + 0.1 min (retry). Records: 4,386 (open models 3 × 1,420 = 1,140 base + 280 hint; frontier 126). Transport errors: 33, all frontier HTTP 429 (OpenAI rate limit). Removed with drop_errors.py and re-run with --workers 3; 0 errors after the retry. No model answers were removed.
9. Parse-failure rate: qwen3-14b 0.14%, llama3.1-8b 0.07%, mistral-small-24b 0.00%, frontier 0.00%.
10. results.jsonl SHA256 (before analyze.py): 78603278ba909e16f52e4c1864f8d25ee846b5a84e2ac7e31466f72287057f53
11. Anomalies:
    - DeepInfra served the Llama ID as "-Turbo" (recorded pre-run).
    - Frontier rate-limited (retried).
    - The frozen item count per open model is 1,420 (the hint slice is 280, not "~285" as estimated in the audit). This is not a deviation: the slice is defined by hash.
