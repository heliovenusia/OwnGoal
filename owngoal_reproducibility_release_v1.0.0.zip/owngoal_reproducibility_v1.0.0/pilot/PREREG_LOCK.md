# OwnGoal micro-pilot: preregistration lock (2026-10-04, before any model output)

Source of design: ../05_OWNGOAL_VERDICT.md, sections Q (design) and R (kill criteria).
Frozen files and hashes: SHA256SUMS.txt. Thresholds live in analyze.py and must not be edited after data exist.

## Pre-data operationalisations
These details were left open by the verdict text. All were fixed *before* any model output existed. None changes a factor, threshold, model family or prompt intent.

1. **Time base.** Δt = 1 decision step. The plant is a discrete FOPDT with ZOH: y[t] = a·y[t−1] + K(1−a)·u[t−1−d], with a = e^(−1/τ). A move is first visible at lag k = d+1.
2. **N = t_s/Δt** is the post-onset 2% settling horizon, so τ = N/ln 50. N=2 gives τ=0.511; N=8 gives τ=2.045. Counting θ inside t_s would make the preregistered cell d=3, N=2 impossible.
3. **Constants.** K = 2 °C per t/h; σ_v = 0.25 °C; move size |Δu| ∈ U(1.5, 2.5) t/h with random sign; W = 12; T = 40; probe at the last step. A minimal-pair disturbance is an input-equivalent step through G_d = G_21, which gives byte-identical y within pairs (verified: max diff 0).
4. **Move channel per authorship.** The y2 table is shown in all framings.
   - own: prior assistant turns ("I increase u1 by ...").
   - third_party: a user-reported shift-log sentence.
   - neutral_log: a "u1 change" column in the table.

   The system prompt is identical across framings. The exogenous twin says "no u1 changes" through the same channel.
5. **Retention** follows the preregistered label rule (|Δy| ≥ 3σ_v, s ≥ 0.8, |I| ≤ 0.1|Δy|).
   - Probe lags with k ≤ d (move not yet visible) are therefore excluded: 360 of 1,080 core items.
   - For d=0, N=2, all three k levels equal 1 (duplicate cells by construction).
6. **"Both" items:** 60 = 3 authorships × 2 N × 10 seeds, d = 1, move and disturbance at the same step, size ratio U(0.8, 1.2). All are labelled "mixed", target answer "both". They are reported separately and not used in KC1–KC5.
7. **Gap** = acc(third_party) − acc(own), paired on matched base items. KC2 uses the signed gap < 5 pp.
8. **d-slope** = OLS slope of correctness on d (own, retained core). **Drop** = acc_own(d=0) − acc_own(d=3), independent-groups bootstrap. B = 10,000, seed 20261004.
9. **KC3 numeric operationalisation:** "fail to flip" means the within-pair flip rate at d=0, N=2 is < 50%, in all 3 open models. The verdict gave no number, so this was fixed pre-data.
10. KC1 and KC4 "every cell" means every d×N cell (6 cells) for every open model. KC4 uses the hint arm, all authorships.
11. **Slices** are chosen by item-id hash: hint = 25% (h mod 4 = 0); frontier = 10% (h mod 10 = 0).
12. **Phantom correction** = action "fault_response" on endogenous items (secondary metric).
13. **Concrete open models** (within the preregistered "e.g." families): qwen3:14b, llama3.1:8b, mistral-small:24b. Frontier is an unspecified slot, descriptive only and not used in the KCs.
14. **Parsing:** last valid JSON object after stripping <think> blocks. Unparseable answers count as incorrect, and the parse-failure rate is reported.
