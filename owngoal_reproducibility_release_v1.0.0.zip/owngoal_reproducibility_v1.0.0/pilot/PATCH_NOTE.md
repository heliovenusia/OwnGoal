# Implementation patch note (execution only, declared before any data)

- **Patch:** `run_models_parallel.py`, a concurrent copy of the frozen `run_models.py`. The frozen file is unchanged (hash in SHA256SUMS.txt).
- **Verification (2026-10-04, mock OpenAI-compatible server, no real model):** both runners issued **4,386 calls with an identical multiset of request bodies** (sha256 per body) and produced identical result records, ignoring line order and latency.
- **Science unchanged:** same items, prompts, models, temperature 0, max_tokens, slices, retry policy and output format. Only the line order of results.jsonl differs, and analyze.py is order-independent.
- **Helper:** `drop_errors.py` removes transport-error records (`__ERROR__`) so a rerun retries only those calls. It never removes model answers, including unparseable ones.
- **Execution config:** `models_deepinfra.json`. The 3 open models are on DeepInfra; the frontier slot is on OpenAI (descriptive only, not in the KCs).
