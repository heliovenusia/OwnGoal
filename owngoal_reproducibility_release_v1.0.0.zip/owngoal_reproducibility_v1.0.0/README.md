# Reproducibility archive: controlled falsification study of causal attribution in language-model supervisory agents

Version: v1.0.0

This public archive contains the simulator, frozen evaluation items, raw model outputs, pre-specified decision records, control experiments, analysis code, canonical results, and provenance needed to reproduce a controlled negative/robustness study of causal attribution in two language models used in a simulated supervisory task.

## Scientific scope
The pilot showed a large apparent self-authorship contrast, but authorship was confounded with action-record placement. A first factorial control exposed an additional wording defect in its OTHER cells. The corrected factorial control produced model-asymmetric results: Qwen3-14B showed a positive authorship contrast, while Mistral-Small-24B was floor-limited at the earlier position. The pre-specified cross-model rule therefore stopped the programme. See `FINAL_SCIENCE_NOTE.md` and `ARCHIVE_ERRATA.md` for the publication interpretation.

## Offline reproduction
From the archive root, install NumPy and run:

`python offline_analysis.py`

The script regenerates `reproduced_canonical_results.csv` from archived raw outputs and reports whether it is byte-identical to `final_analysis/canonical_results.csv`. No API key or network connection is required.

## Hosted-model reproducibility
The archived outputs are the reproducibility anchor. Exact future API reruns may differ because hosted deployments, serving software, quantization, and provider infrastructure can change. Requested model identifiers and execution records are retained where scientifically relevant.

## Structure
- `pilot/`: frozen pilot materials and raw outputs
- `control1/`: first factorial control, retained with its known wording defect
- `control2/`: corrected factorial control
- `final_analysis/`: canonical analysis snapshot and result table
- `src/`: benchmark and execution utilities
- `docs/`: selected chronological scientific reports
- `FINAL_SCIENCE_NOTE.md`: final publication interpretation
- `ARCHIVE_ERRATA.md`: known corrections and interpretation notes

## Licensing
Code is released under the MIT License (`LICENSE_CODE.txt`). Generated data and results are released under CC BY 4.0 (`LICENSE_DATA.txt`). Third-party model software and weights are not redistributed.

## Creator
Sethuraman Kannan, Independent Researcher, India. ORCID 0009-0000-4165-5431.
