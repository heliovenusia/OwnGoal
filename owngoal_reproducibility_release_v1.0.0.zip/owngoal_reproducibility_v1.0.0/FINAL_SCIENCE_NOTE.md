# Final science note

This archive supports a controlled falsification study of causal attribution in two language models used in a simulated supervisory task.

The large pilot contrast did not establish a stable cross-model self-authorship mechanism. The pilot confounded authorship with action-record placement. In the corrected factorial control, Qwen3-14B showed a positive authorship contrast, while Mistral-Small-24B was floor-limited at the earlier position and therefore did not provide informative evidence of absence or equivalence. The pre-specified cross-model decision rule consequently stopped the programme.

The first factorial control contained contradictory wording in its OTHER cells and is retained as provenance, not as a clean estimate of the intended authorship contrast. The second factorial control is the clean corrected control.

A response-choice analysis is retained only as a response-coherence check because the available action set was asymmetric with respect to deviation sign. Exact future hosted-model reruns may differ; archived raw outputs are the reproducibility anchor.
