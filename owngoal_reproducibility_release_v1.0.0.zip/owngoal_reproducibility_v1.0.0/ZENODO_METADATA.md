# Zenodo metadata

**Title:** Reproducibility archive for a controlled falsification study of causal attribution in language-model supervisory agents

**Creator:** Sethuraman Kannan (Independent Researcher, India; ORCID 0009-0000-4165-5431)

**Version:** v1.0.0

**Description:** Code, frozen evaluation items, raw model outputs, pre-specified decision records, control experiments, canonical analyses, and reproducibility materials supporting a negative/robustness study of causal attribution in two language models used in a simulated supervisory task. The archive documents a large pilot contrast, the confounds revealed by matched controls, the model-asymmetric corrected-control result, and the pre-specified stopping decision. No proprietary industrial data are used.

**Keywords:** large language models; LLM agents; causal attribution; evaluation robustness; reproducibility; process supervision; negative results; matched controls

**Licenses:** MIT for code; CC BY 4.0 for generated data/results.

**DOI:** to be assigned by Zenodo at deposit.
