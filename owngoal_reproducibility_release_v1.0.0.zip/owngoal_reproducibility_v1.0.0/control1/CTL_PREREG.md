# OwnGoal confound-resolution control: freeze record (2026-10-05, before any model call)

Brief: Orchestrator "confound-resolution experiment" (2×2 authorship × position). The pilot plant, generator and parser are reused unchanged (../owngoal.py, ../analyze.py.parse; frozen hashes in ../SHA256SUMS.txt).

## Design
- **Situations:** 60 retained minimal pairs, 10 per d×N cell, chosen as the lowest sha256("ctl|d|N|k_idx|seed") in each cell. Dead time and settling horizon are balanced nuisance factors.
- **Items:** 60 situations × 2 causes (own_move / exogenous twin, identical y) × 4 cells = **480 per model**.
- **Cells:**
  - A = OWN/EARLIER;
  - B = OWN/RECENT;
  - C = OTHER/EARLIER;
  - D = OTHER/RECENT.
- **Manipulation:** identical dialogue skeleton in every cell.
  - **OWN:** the assistant turn at the move step reads "Step s: I increase u1 by X t/h to adjust throughput."
  - **OTHER:** the user turn at the same step adds "Operator B increased u1 by X t/h to adjust throughput at this step." The assistant turn reads "hold u1 (no change)".
  - **RECENT:** the final message adds "For reference: at step s you / Operator B increased u1 by X t/h to adjust throughput." Exogenous twins get "For reference: you / Operator B made no u1 changes in this window."
  - No causal hint anywhere.
- **Validation (ctl_validate.py):** PASS.
  - 120 quadruplets with 0 problems; physics fields identical within each quadruplet.
  - The only differing messages are the move-step user/assistant turns and the final message.
  - y identical across cause twins; ideal observer 1.000.
- **Models:**
  - primary: Qwen/Qwen3-14B (max_tokens 4096) and mistralai/Mistral-Small-24B-Instruct-2501 (max_tokens 1024), both on DeepInfra;
  - frontier spot check: gpt-4.1-2025-04-14 on a 10% situation slice (48 items, descriptive only);
  - Llama is excluded.
  - Temperature 0, same request format as the pilot. The runner is ctl_run.py (concurrent; same call function as the verified parallel runner).

## Primary outcome and estimands
- **Primary outcome:** correct attribution on own_move (endogenous) items.
- **Matched quadruplet bootstrap** over situations (B = 10,000, seed 20261005).
- **Estimands:**
  - Δ_A = mean[(C+D)/2 − (A+B)/2];
  - Δ_P = mean[(B+D)/2 − (A+C)/2];
  - Δ_AP = mean[(C−A) − (D−B)].
- **Contrasts:**
  - C1 = C−A (authorship at EARLIER);
  - C2 = D−B (authorship at RECENT);
  - C3 = B−A (recency within OWN);
  - C4 = D−C (recency within OTHER).

## Pre-data interpretation rules (must hold in BOTH Qwen and Mistral)
"sig(x, t)" means estimate ≥ t **and** CI lower bound > 0.
- **A1:** sig(Δ_A, 0.10).
- **A2:** sig(C1, 0.10) or sig(C2, 0.10).
- **A3** (not almost entirely recency; operationalisation fixed here): Δ_A / (Δ_A + max(Δ_P, 0)) ≥ 1/3.
- **Position material:** sig(Δ_P, 0.10).

**Decision order:**
1. A1 ∧ A2 ∧ A3 (both models) **and** position material (both) → **MIXED MECHANISM**; full study authorized with joint wording.
2. A1 ∧ A2 ∧ A3 (both models) → **AUTHORSHIP EFFECT SURVIVES**; full study authorized.
3. Position-only, i.e. in both models |C1| < 0.05 with CI ∋ 0, |C2| < 0.05 with CI ∋ 0, sig(C3, 0.10) and sig(C4, 0.10) → **AUTHORSHIP HYPOTHESIS KILLED; EFFECT IS POSITION/RECENCY.**
4. Neither Δ_A nor Δ_P is sig at 0.10 in either model → **PILOT EFFECT DOES NOT REPLICATE: KILL/PIVOT.**
5. Otherwise → **UNRESOLVED → ONE FURTHER CONTROL.**

The decision logic was plumbing-tested with pseudo-models; each branch fired as intended.

**Secondary (descriptive, no new outcomes):**
- exogenous-item accuracy per cell (answer-bias guard);
- confidence on correct vs wrong, Brier;
- fault_response rate;
- P(fault_response | external belief) vs P(fault_response | move belief);
- Δ_A by dead time.

**Correctness is not inspected during execution.** Only transport errors and parse failures are monitored.
