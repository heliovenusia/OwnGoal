"""Frozen analysis + interpretation rules for the 2x2 confound-resolution control.
Thresholds and decision logic are fixed here BEFORE any model call (CTL_PREREG.md).
Usage: python ctl_analyze.py ctl_results.jsonl ctl_report.json"""
import json, os, re, sys, collections
import numpy as np
H = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(H, ".."))
from analyze import parse            # frozen pilot parser (unchanged)
from owngoal import TARGET

B = 10_000; SEED = 20261005
PRIMARY = ["qwen3-14b", "mistral-small-24b"]
T_MAIN = 0.10      # A1, A2, position materiality, C3/C4 for position-only
T_NULLAUTH = 0.05  # |C1|,|C2| below this (with CI containing 0) = "similar once position matched"
A3_SHARE = 1 / 3   # authorship must account for >= 1/3 of the combined positive main effects

def ci(x):
    x = np.asarray(x, float); r = np.random.default_rng(SEED)
    bs = x[r.integers(0, len(x), (B, len(x)))].mean(1)
    return dict(est=float(x.mean()), lo=float(np.percentile(bs, 2.5)), hi=float(np.percentile(bs, 97.5)), n=int(len(x)))

def sig(c, t=T_MAIN): return c["est"] >= t and c["lo"] > 0

def analyze(path):
    items = {json.loads(l)["item_id"]: json.loads(l) for l in open(os.path.join(H, "ctl_items.jsonl"))}
    rows = []
    for l in open(path):
        r = json.loads(l); it = items[r["item_id"]]
        c, conf, act = parse(r["raw"])
        rows.append(dict(model=r["model_tag"], sit=it["situation"], cause=it["cause"], a=it["authorship"],
                         p=it["position"], d=it["d"], N=it["N"], label=it["label"], pred=c, conf=conf, act=act,
                         correct=int(c == TARGET[it["label"]])))
    rep = {"models": {}}
    for m in sorted({r["model"] for r in rows}):
        R = [r for r in rows if r["model"] == m]
        out = {"n_calls": len(R), "parse_fail": float(np.mean([r["pred"] is None for r in R]))}
        endo = [r for r in R if r["cause"] == "own_move"]
        exo = [r for r in R if r["cause"] == "exogenous"]
        cell = lambda rs, a, p: [r for r in rs if r["a"] == a and r["p"] == p]
        out["cells_endo"] = {f"{a}/{p}": ci([r["correct"] for r in cell(endo, a, p)]) for a in ["OWN", "OTHER"] for p in ["EARLIER", "RECENT"]}
        out["cells_exo"] = {f"{a}/{p}": ci([r["correct"] for r in cell(exo, a, p)]) for a in ["OWN", "OTHER"] for p in ["EARLIER", "RECENT"]}
        # per-situation matched quadruplets (endogenous)
        S = collections.defaultdict(dict)
        for r in endo: S[r["sit"]][(r["a"], r["p"])] = r["correct"]
        full = [v for v in S.values() if len(v) == 4]
        A = np.array([v[("OWN", "EARLIER")] for v in full]); Bc = np.array([v[("OWN", "RECENT")] for v in full])
        C = np.array([v[("OTHER", "EARLIER")] for v in full]); D = np.array([v[("OTHER", "RECENT")] for v in full])
        out["n_quadruplets"] = len(full)
        if len(full) >= 2:
            out["delta_A"] = ci((C + D) / 2 - (A + Bc) / 2)
            out["delta_P"] = ci((Bc + D) / 2 - (A + C) / 2)
            out["delta_AP"] = ci((C - A) - (D - Bc))
            out["C1_auth_at_EARLIER"] = ci(C - A); out["C2_auth_at_RECENT"] = ci(D - Bc)
            out["C3_recency_within_OWN"] = ci(Bc - A); out["C4_recency_within_OTHER"] = ci(D - C)
            # plant sensitivity (descriptive): delta_A by d
            byd = collections.defaultdict(list)
            sitd = {r["sit"]: r["d"] for r in endo}
            for s, v in S.items():
                if len(v) == 4:
                    byd[sitd[s]].append((v[("OTHER", "EARLIER")] + v[("OTHER", "RECENT")] - v[("OWN", "EARLIER")] - v[("OWN", "RECENT")]) / 2)
            out["delta_A_by_d"] = {str(k): ci(v) for k, v in sorted(byd.items())}
        # secondary: confidence, calibration, action
        sec = {}
        for a in ["OWN", "OTHER"]:
            for p in ["EARLIER", "RECENT"]:
                rs = cell(endo, a, p)
                cc = [r for r in rs if r["conf"] is not None]
                sec[f"{a}/{p}"] = dict(
                    mean_conf_correct=float(np.mean([r["conf"] for r in cc if r["correct"]])) if any(r["correct"] for r in cc) else None,
                    mean_conf_wrong=float(np.mean([r["conf"] for r in cc if not r["correct"]])) if any(not r["correct"] for r in cc) else None,
                    brier=float(np.mean([(r["conf"] / 100 - r["correct"]) ** 2 for r in cc])) if cc else None,
                    fault_response_rate=float(np.mean([r["act"] == "fault_response" for r in rs])) if rs else None,
                    p_fault_given_external_belief=(float(np.mean([r["act"] == "fault_response" for r in rs if r["pred"] == "external_disturbance_or_fault"]))
                                                   if any(r["pred"] == "external_disturbance_or_fault" for r in rs) else None),
                    p_fault_given_move_belief=(float(np.mean([r["act"] == "fault_response" for r in rs if r["pred"] == "earlier_u1_move"]))
                                               if any(r["pred"] == "earlier_u1_move" for r in rs) else None),
                    answer_dist=dict(collections.Counter(r["pred"] for r in rs)))
        out["secondary_endo"] = sec
        rep["models"][m] = out
    # ---------------- frozen decision rules (primary models only) ----------------
    P = [rep["models"][m] for m in PRIMARY if m in rep["models"] and "delta_A" in rep["models"][m]]
    dec = {}
    if len(P) == len(PRIMARY):
        def a3(o):
            dA, dP = o["delta_A"]["est"], max(o["delta_P"]["est"], 0.0)
            return (dA / (dA + dP)) >= A3_SHARE if dA > 0 else False
        per = {}
        for m in PRIMARY:
            o = rep["models"][m]
            per[m] = dict(A1=sig(o["delta_A"]), A2=sig(o["C1_auth_at_EARLIER"]) or sig(o["C2_auth_at_RECENT"]), A3=a3(o),
                          POS_material=sig(o["delta_P"]),
                          C1_null=abs(o["C1_auth_at_EARLIER"]["est"]) < T_NULLAUTH and o["C1_auth_at_EARLIER"]["lo"] <= 0 <= o["C1_auth_at_EARLIER"]["hi"],
                          C2_null=abs(o["C2_auth_at_RECENT"]["est"]) < T_NULLAUTH and o["C2_auth_at_RECENT"]["lo"] <= 0 <= o["C2_auth_at_RECENT"]["hi"],
                          C3_sig=sig(o["C3_recency_within_OWN"]), C4_sig=sig(o["C4_recency_within_OTHER"]),
                          A_sig=sig(o["delta_A"]), P_sig=sig(o["delta_P"]))
        auth = all(per[m]["A1"] and per[m]["A2"] and per[m]["A3"] for m in PRIMARY)
        posmat = all(per[m]["POS_material"] for m in PRIMARY)
        posonly = all(per[m]["C1_null"] and per[m]["C2_null"] and per[m]["C3_sig"] and per[m]["C4_sig"] for m in PRIMARY)
        null = all(not per[m]["A_sig"] and not per[m]["P_sig"] for m in PRIMARY)
        if auth and posmat: verdict = "MIXED MECHANISM (authorship survives; position is a second factor) -> FULL STUDY AUTHORIZED"
        elif auth: verdict = "AUTHORSHIP EFFECT SURVIVES -> FULL STUDY AUTHORIZED"
        elif posonly: verdict = "AUTHORSHIP HYPOTHESIS KILLED. EFFECT IS POSITION/RECENCY."
        elif null: verdict = "PILOT EFFECT DOES NOT REPLICATE UNDER CONTROL -> KILL/PIVOT"
        else: verdict = "UNRESOLVED (no pre-data rule fully satisfied) -> ONE FURTHER CONTROL"
        dec = dict(per_model=per, authorship_path=auth, position_material_both=posmat, position_only=posonly, null=null, verdict=verdict)
    rep["decision"] = dec
    return rep

if __name__ == "__main__":
    rep = analyze(sys.argv[1] if len(sys.argv) > 1 else "ctl_results.jsonl")
    json.dump(rep, open(sys.argv[2] if len(sys.argv) > 2 else "ctl_report.json", "w"), indent=2)
    print(json.dumps(rep["decision"], indent=2))
