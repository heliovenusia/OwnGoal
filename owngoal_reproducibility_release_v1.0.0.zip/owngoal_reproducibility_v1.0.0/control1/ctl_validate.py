"""Programmatic validation of matched quadruplets (brief section 7 + 21.3)."""
import json, os, collections, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from owngoal import observer, TARGET
H = os.path.dirname(__file__)
items = [json.loads(l) for l in open(os.path.join(H, "ctl_items.jsonl"))]
Q = collections.defaultdict(list)
for i in items: Q[(i["situation"], i["cause"])].append(i)
problems = []
for key, grp in Q.items():
    if sorted((g["authorship"], g["position"]) for g in grp) != sorted([(a, p) for a in ["OWN", "OTHER"] for p in ["EARLIER", "RECENT"]]):
        problems.append((key, "cells")); continue
    ref = grp[0]
    for g in grp[1:]:
        for f in ["y_obs", "u_steps", "dist_steps", "t_probe", "label", "d", "N", "k", "seed"]:
            if g[f] != ref[f]: problems.append((key, f))
    # message-level diff: only the move-step turn(s) and the final message may differ
    for g in grp:
        if len(g["messages"]) != len(ref["messages"]): problems.append((key, "len"))
    diffidx = set()
    for g in grp:
        for j, (m1, m2) in enumerate(zip(g["messages"], ref["messages"])):
            if m1 != m2: diffidx.add(j)
    n = len(ref["messages"])
    allowed = {n - 1}
    if ref["u_steps"]:
        t0 = ref["u_steps"][0][0]; lo = ref["t_probe"] - 12 + 1
        ui = 1 + 2 * (t0 - lo); allowed |= {ui, ui + 1}
    if not diffidx <= allowed: problems.append((key, f"unexpected diff at {sorted(diffidx - allowed)}"))
    # system prompt + question identical
    if len({g["messages"][0]["content"] for g in grp}) != 1: problems.append((key, "system"))
    if len({g["messages"][-1]["content"].split("Answer three questions")[1] for g in grp}) != 1: problems.append((key, "question"))
# exogenous twins: EARLIER prompts for OWN and OTHER are identical (no move anywhere), by design
ex_same = sum(1 for (s, c), grp in Q.items() if c == "exogenous" and
              {json.dumps(g["messages"]) for g in grp if g["position"] == "EARLIER"}.__len__() == 1)
# minimal-pair identity across causes
pairs = collections.defaultdict(dict)
for i in items: pairs[(i["situation"], i["authorship"], i["position"])][i["cause"]] = i["y_obs"]
pair_ok = all(v["own_move"] == v["exogenous"] for v in pairs.values())
# ideal observer still decides every situation
ideal = [observer(i, True)[0] == TARGET[i["label"]] for i in items if i["authorship"] == "OWN" and i["position"] == "EARLIER"]
cells = collections.Counter((i["d"], i["N"]) for i in items if i["authorship"] == "OWN" and i["position"] == "EARLIER" and i["cause"] == "own_move")
print("items", len(items), "| quadruplets", len(Q), "| problems", len(problems))
for p in problems[:10]: print("  PROBLEM", p)
print("labels:", dict(collections.Counter(i["label"] for i in items)))
print("situations per d x N:", dict(cells))
print("y identical within own/exo pairs:", pair_ok)
print("exogenous EARLIER OWN==OTHER prompt (expected, no move exists):", ex_same, "of", len(Q) // 2)
print(f"ideal-observer accuracy on control situations: {sum(ideal)/len(ideal):.3f}")
ok = not problems and pair_ok and sum(ideal) / len(ideal) >= 0.98
print("VALIDATION", "PASS" if ok else "FAIL")
json.dump(dict(problems=[str(p) for p in problems], pair_ok=pair_ok, ideal=sum(ideal)/len(ideal), passed=ok),
          open(os.path.join(H, "ctl_validation.json"), "w"), indent=2)
