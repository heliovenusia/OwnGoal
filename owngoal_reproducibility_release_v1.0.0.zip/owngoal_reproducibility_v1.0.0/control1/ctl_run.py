"""Concurrent runner for the control (same request format as the frozen pilot runner:
temperature 0, max_tokens from config, /chat/completions, 3 attempts with 5/10/15 s backoff).
Messages are taken verbatim from ctl_items.jsonl. Frontier model only on frontier_slice items.
Usage: python ctl_run.py ctl_models.json [--workers 24]"""
import argparse, json, os, sys, threading, time
from concurrent.futures import ThreadPoolExecutor, as_completed
H = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(H, ".."))
from run_models_parallel import call

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("config"); ap.add_argument("--workers", type=int, default=24)
    ap.add_argument("--out", default=os.path.join(H, "ctl_results.jsonl")); a = ap.parse_args()
    cfg = json.load(open(a.config)); items = [json.loads(l) for l in open(os.path.join(H, "ctl_items.jsonl"))]
    done = set()
    if os.path.exists(a.out):
        for l in open(a.out):
            if l.strip(): r = json.loads(l); done.add((r["model_tag"], r["item_id"]))
    jobs = [(m, it) for m in cfg["models"] for it in items
            if (m["role"] != "frontier" or it["frontier_slice"]) and (m["tag"], it["item_id"]) not in done]
    print(f"{len(done)} done; {len(jobs)} to run", flush=True)
    def work(m, it):
        key = os.environ.get(m.get("api_key_env", ""), "")
        for att in range(3):
            try:
                t0 = time.time(); txt = call(m["endpoint"], m["model"], key, it["messages"], m.get("max_tokens", 1024)); break
            except Exception as e:
                txt = f"__ERROR__ {e}"; time.sleep(5 * (att + 1))
        return {"model_tag": m["tag"], "role": m["role"], "item_id": it["item_id"], "raw": txt, "latency_s": round(time.time() - t0, 2)}
    lock = threading.Lock(); n = errs = 0; ts = time.time()
    with open(a.out, "a") as f, ThreadPoolExecutor(a.workers) as ex:
        for fu in as_completed([ex.submit(work, *j) for j in jobs]):
            r = fu.result()
            with lock:
                f.write(json.dumps(r) + "\n"); f.flush(); n += 1; errs += r["raw"].startswith("__ERROR__")
                if n % 50 == 0 or n == len(jobs):
                    print(f"  {n}/{len(jobs)} | errors {errs} | {(time.time()-ts)/60:.1f} min", flush=True)
    print("finished; errors", errs)

if __name__ == "__main__":
    main()
