"""Windows-friendly check of SHA256SUMS.txt (frozen files)."""
import hashlib
bad = 0
for line in open("SHA256SUMS.txt"):
    h, name = line.split()
    got = hashlib.sha256(open(name, "rb").read()).hexdigest()
    print(("OK  " if got == h else "BAD ") + name); bad += got != h
print("ALL FROZEN FILES OK" if not bad else f"{bad} MISMATCH - STOP")
