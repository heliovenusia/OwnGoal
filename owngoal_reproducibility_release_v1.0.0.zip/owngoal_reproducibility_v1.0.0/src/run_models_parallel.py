"""DOCUMENTED IMPLEMENTATION PATCH (execution only) of the frozen run_models.py.

What is identical to the frozen runner (verified against it, see PATCH_NOTE.md):
  * the set of (model, item, arm) calls, including the frontier 10% slice and the hint 25% slice;
  * every request body: messages from owngoal.build_messages, temperature 0, max_tokens from config;
  * the endpoint path (/chat/completions), auth header, 3 attempts with 5 s / 10 s / 15 s backoff;
  * the output record format in results.jsonl (model_tag, role, item_id, arm, raw, latency_s);
  * resumability (skips any (model, item, arm) already present in results.jsonl).
What differs: requests are sent concurrently (thread pool), so results.jsonl line order differs.
Line order is irrelevant: analyze.py scores every record independently.

Usage:  python run_models_parallel.py models_deepinfra.json [--workers 16] [--only TAG ...]
"""
import argparse, json, os, threading, time, urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from owngoal import all_items, build_messages

def call(endpoint, model, key, messages, max_tokens, timeout=600):
    body = json.dumps({"model": model, "messages": messages, "temperature": 0,
                       "max_tokens": max_tokens}).encode()
    req = urllib.request.Request(endpoint.rstrip("/") + "/chat/completions", data=body,
                                 headers={"Content-Type": "application/json",
                                          **({"Authorization": f"Bearer {key}"} if key else {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())["choices"][0]["message"]["content"]

def jobs_for(cfg, items, done, only):
    for m in cfg["models"]:
        if only and m["tag"] not in only:
            continue
        for it in items:
            if m["role"] == "frontier" and not it["frontier_slice"]:
                continue
            arms = ["base"] + (["hint"] if (m["role"] == "open" and it["hint_slice"]) else [])
            for arm in arms:
                if (m["tag"], it["item_id"], arm) not in done:
                    yield m, it, arm

def work(m, it, arm):
    key = os.environ.get(m.get("api_key_env", ""), "")
    msgs = build_messages(it, hint=(arm == "hint"))
    for attempt in range(3):
        try:
            t0 = time.time()
            txt = call(m["endpoint"], m["model"], key, msgs, m.get("max_tokens", 1024))
            break
        except Exception as e:
            txt = f"__ERROR__ {e}"; time.sleep(5 * (attempt + 1))
    return {"model_tag": m["tag"], "role": m["role"], "item_id": it["item_id"],
            "arm": arm, "raw": txt, "latency_s": round(time.time() - t0, 2)}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("config"); ap.add_argument("--workers", type=int, default=16)
    ap.add_argument("--out", default="results.jsonl"); ap.add_argument("--only", nargs="*")
    a = ap.parse_args()
    cfg = json.load(open(a.config)); items = all_items()
    done = set()
    if os.path.exists(a.out):
        for line in open(a.out, encoding="utf-8"):
            if line.strip():
                r = json.loads(line); done.add((r["model_tag"], r["item_id"], r["arm"]))
    jobs = list(jobs_for(cfg, items, done, a.only))
    print(f"{len(done)} already done; {len(jobs)} calls to make with {a.workers} workers")
    lock = threading.Lock(); n = 0; errs = 0; t_start = time.time()
    with open(a.out, "a", encoding="utf-8") as f, ThreadPoolExecutor(a.workers) as ex:
        futs = [ex.submit(work, *j) for j in jobs]
        for fu in as_completed(futs):
            rec = fu.result()
            with lock:
                f.write(json.dumps(rec) + "\n"); f.flush()
                n += 1; errs += rec["raw"].startswith("__ERROR__")
                if n % 50 == 0 or n == len(jobs):
                    el = time.time() - t_start
                    print(f"  {n}/{len(jobs)} done | errors {errs} | {el/60:.1f} min elapsed | "
                          f"ETA {el/n*(len(jobs)-n)/60:.1f} min", flush=True)
    print(f"finished. errors this pass: {errs}. If >0: python drop_errors.py {a.out}  then rerun this command (retries only those calls).")

if __name__ == "__main__":
    main()
