"""Remove transport-error records (raw starts with __ERROR__) so a rerun retries only those calls.
Keeps a backup. Model answers (including unparseable ones) are never removed."""
import json, shutil, sys
p = sys.argv[1] if len(sys.argv) > 1 else "results.jsonl"
shutil.copy(p, p + ".bak")
keep, dropped = [], 0
for line in open(p, encoding="utf-8"):
    if not line.strip(): continue
    if json.loads(line)["raw"].startswith("__ERROR__"): dropped += 1
    else: keep.append(line)
open(p, "w", encoding="utf-8").writelines(keep)
print(f"dropped {dropped} error records; kept {len(keep)}; backup at {p}.bak")
