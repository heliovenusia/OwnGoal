"""PLUMBING TEST ONLY: no LLM involved. Feeds deterministic pseudo-models through
analyze.py to verify each kill criterion can fire. Outputs are NOT pilot data."""
import json
from owngoal import all_items, observer
from analyze import analyze

def write(path, policy):
    with open(path, "w") as f:
        for tag, fn in policy.items():
            for it in all_items():
                for arm in ["base"] + (["hint"] if it["hint_slice"] else []):
                    c = fn(it, arm)
                    f.write(json.dumps({"model_tag": tag, "role": "open", "item_id": it["item_id"], "arm": arm,
                                        "raw": json.dumps({"cause": c, "confidence": 80, "action": "hold_and_monitor"})}) + "\n")

ideal = lambda it, arm: observer(it, True)[0]
blind = lambda it, arm: observer(it, False)[0]
# synthetic 'self-blind': ideal except own-authorship items at d>=1, where it ignores the log
selfblind = lambda it, arm: (observer(it, False)[0] if (it["authorship"] == "own" and it["d"] >= 1 and arm == "base") else observer(it, True)[0])

for name, pol in {"A_all_ideal(expect KC1+KC4)": ideal, "B_all_logblind(expect KC3)": blind,
                  "C_selfblind(expect KC5)": selfblind}.items():
    write("/tmp/_pt.jsonl", {f"m{i}": pol for i in range(3)})
    rep = analyze("/tmp/_pt.jsonl")
    print(name, {k: v for k, v in rep["kc_fired"].items() if v})
