"""Model-free preregistered integrity gate (05_OWNGOAL_VERDICT.md, R 'Integrity').
Ideal observer must reach >=98% on retained items; log-blind observer should be ~50% on pairs."""
import json, collections
import numpy as np
from owngoal import all_items, retained, observer, TARGET

its = all_items()
ret = [i for i in its if retained(i)]
core = [i for i in its if i["kind"] == "core"]
print(f"total items: {len(its)}  (core {len(core)}, both {len(its)-len(core)})")
print("label distribution (all):", dict(collections.Counter(i['label'] for i in its)))
print(f"retained: {len(ret)}")

# per-cell retention
cell = collections.Counter((i['d'], i['N'], i['k']) for i in core if retained(i))
tot = collections.Counter((i['d'], i['N'], i['k']) for i in core)
print("core retention by (d,N,k):")
for key in sorted(tot): print("  ", key, f"{cell[key]}/{tot[key]}")

# minimal-pair identity check: y identical within pairs
pairs = collections.defaultdict(list)
for i in core: pairs[i['pair_id']].append(i)
maxdiff = max(np.max(np.abs(np.array(a['y_obs']) - np.array(b['y_obs']))) for a, b in pairs.values())
print(f"max |y_own - y_exo| within minimal pairs: {maxdiff:.2e}")

# interaction must be ~0 (linear plant)
print(f"max |interaction|: {max(abs(i['interaction']) for i in its):.2e}")

# observers (authorship does not affect observers -> evaluate one authorship copy)
uniq = [i for i in ret if i['authorship'] == 'own']
res = collections.defaultdict(lambda: [0, 0])
blind = collections.defaultdict(lambda: [0, 0])
for i in uniq:
    a, _ = observer(i, use_log=True); b, _ = observer(i, use_log=False)
    key = i['kind']
    res[key][0] += (a == TARGET[i['label']]); res[key][1] += 1
    blind[key][0] += (b == TARGET[i['label']]); blind[key][1] += 1
out = {}
for k in res:
    out[k] = dict(ideal=res[k][0] / res[k][1], log_blind=blind[k][0] / blind[k][1], n=res[k][1])
    print(f"[{k}] ideal observer acc = {out[k]['ideal']:.3f}   log-blind acc = {out[k]['log_blind']:.3f}   n={res[k][1]}")
allc = sum(r[0] for r in res.values()); alln = sum(r[1] for r in res.values())
out['overall_ideal'] = allc / alln
gate = out['overall_ideal'] >= 0.98
print(f"OVERALL ideal = {out['overall_ideal']:.3f} -> integrity gate {'PASS' if gate else 'FAIL (labelling bug: fix before any model data)'}")
out['gate_pass'] = gate
json.dump(out, open('integrity_result.json', 'w'), indent=2)
