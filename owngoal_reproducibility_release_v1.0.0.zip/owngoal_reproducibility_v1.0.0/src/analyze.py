"""Analysis + preregistered kill-criteria evaluator (05_OWNGOAL_VERDICT.md, section R).
Thresholds below are copied from the preregistration and MUST NOT be edited after data exist.

Usage: python analyze.py results.jsonl  -> analysis_report.json + printed KC verdicts
"""
import json, re, sys, collections
import numpy as np
from owngoal import all_items, retained, TARGET, D_LEVELS, N_LEVELS

B = 10_000
RNG = np.random.default_rng(20261004)
KC1_ACC = 0.90; KC2_GAP = 0.05; KC4_ACC = 0.90
KC5_GAP = 0.10; KC5_DROP = 0.15
KC3_FLIP = 0.50   # pre-data operationalisation of "answers fail to flip" (flip rate < 50%)
CAUSE_SET = {"earlier_u1_move", "external_disturbance_or_fault", "both", "cannot_determine"}

def parse(raw):
    txt = re.sub(r"<think>.*?</think>", "", raw or "", flags=re.S)
    m = re.findall(r"\{[^{}]*\}", txt, flags=re.S)
    for cand in reversed(m):
        try:
            j = json.loads(cand)
            c = j.get("cause")
            if c in CAUSE_SET:
                conf = j.get("confidence")
                try: conf = float(conf)
                except Exception: conf = None
                return c, conf, j.get("action")
        except Exception:
            continue
    return None, None, None

def boot_mean(x):
    x = np.asarray(x, float)
    if len(x) == 0: return (float("nan"),) * 3
    bs = x[RNG.integers(0, len(x), (B, len(x)))].mean(1)
    return float(x.mean()), float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))

def boot_diff_paired(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    dlt = a - b
    return boot_mean(dlt)

def boot_diff_indep(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    if len(a) == 0 or len(b) == 0: return (float("nan"),) * 3
    bs = a[RNG.integers(0, len(a), (B, len(a)))].mean(1) - b[RNG.integers(0, len(b), (B, len(b)))].mean(1)
    return float(a.mean() - b.mean()), float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))

def boot_slope(dvals, y):
    dvals, y = np.asarray(dvals, float), np.asarray(y, float)
    def sl(dd, yy):
        v = dd.var()
        return float(((dd - dd.mean()) * (yy - yy.mean())).mean() / v) if v > 0 else float("nan")
    idx = RNG.integers(0, len(y), (B, len(y)))
    bs = np.array([sl(dvals[i], y[i]) for i in idx])
    return sl(dvals, y), float(np.nanpercentile(bs, 2.5)), float(np.nanpercentile(bs, 97.5))

def analyze(results_path):
    items = {i["item_id"]: i for i in all_items()}
    rows = []
    for line in open(results_path):
        r = json.loads(line)
        it = items[r["item_id"]]
        c, conf, act = parse(r["raw"])
        rows.append(dict(**r, **{k: it[k] for k in ("kind", "d", "N", "k", "seed", "cause", "authorship",
                                                      "label", "pair_id", "k_idx")},
                         retained=retained(it), pred=c, conf=conf, action=act,
                         correct=int(c == TARGET.get(it["label"], "__none__"))))
    report = {"models": {}}
    open_models = sorted({r["model_tag"] for r in rows if r["role"] == "open"})
    kc = {m: {} for m in open_models}
    for m in sorted({r["model_tag"] for r in rows}):
        R = [r for r in rows if r["model_tag"] == m]
        base = [r for r in R if r["arm"] == "base" and r["retained"] and r["kind"] == "core"]
        rep = {"n_calls": len(R), "parse_fail_rate": float(np.mean([r["pred"] is None for r in R])) if R else None}
        # accuracy by authorship x d x N
        cells = {}
        for a in ["own", "third_party", "neutral_log"]:
            for d in D_LEVELS:
                for N in N_LEVELS:
                    x = [r["correct"] for r in base if r["authorship"] == a and r["d"] == d and r["N"] == N]
                    cells[f"{a}|d{d}|N{N}"] = dict(zip(("acc", "lo", "hi"), boot_mean(x)), n=len(x))
        rep["acc_cells"] = cells
        # paired own vs third_party gap (third - own) on matched base items
        key = lambda r: (r["d"], r["N"], r["k_idx"], r["seed"], r["cause"])
        own = {key(r): r["correct"] for r in base if r["authorship"] == "own"}
        thp = {key(r): r["correct"] for r in base if r["authorship"] == "third_party"}
        common = sorted(set(own) & set(thp))
        g = boot_diff_paired([thp[k] for k in common], [own[k] for k in common])
        rep["gap_third_minus_own"] = dict(zip(("est", "lo", "hi"), g), n=len(common))
        ow = [r for r in base if r["authorship"] == "own"]
        rep["d_slope_own"] = dict(zip(("est", "lo", "hi"), boot_slope([r["d"] for r in ow], [r["correct"] for r in ow])))
        dr = boot_diff_indep([r["correct"] for r in ow if r["d"] == 0], [r["correct"] for r in ow if r["d"] == 3])
        rep["drop_own_d0_minus_d3"] = dict(zip(("est", "lo", "hi"), dr))
        # flip rate within minimal pairs at d=0, N=2 (all authorships)
        P = collections.defaultdict(dict)
        for r in R:
            if r["arm"] == "base" and r["kind"] == "core" and r["d"] == 0 and r["N"] == 2 and r["retained"]:
                P[r["pair_id"]][r["cause"]] = r["pred"]
        flips = [int(v.get("own_move") != v.get("exogenous")) for v in P.values() if len(v) == 2]
        rep["flip_rate_d0_N2"] = dict(zip(("est", "lo", "hi"), boot_mean(flips)), n=len(flips))
        # hint arm cells
        hint = [r for r in R if r["arm"] == "hint" and r["retained"] and r["kind"] == "core"]
        rep["hint_cells"] = {f"d{d}|N{N}": dict(zip(("acc", "lo", "hi"),
                             boot_mean([r["correct"] for r in hint if r["d"] == d and r["N"] == N])),
                             n=len([1 for r in hint if r["d"] == d and r["N"] == N]))
                             for d in D_LEVELS for N in N_LEVELS}
        # secondary: both-items, calibration, phantom correction
        bo = [r for r in R if r["arm"] == "base" and r["kind"] == "both" and r["retained"]]
        rep["both_items_acc"] = dict(zip(("acc", "lo", "hi"), boot_mean([r["correct"] for r in bo])), n=len(bo))
        cc = [(r["conf"] / 100.0, r["correct"]) for r in base if r["conf"] is not None]
        rep["brier"] = float(np.mean([(p - y) ** 2 for p, y in cc])) if cc else None
        endo = [r for r in base if r["label"] == "endogenous"]
        rep["phantom_correction_rate_by_auth"] = {a: boot_mean([int(r["action"] == "fault_response") for r in endo if r["authorship"] == a])[0] for a in ["own", "third_party", "neutral_log"]}
        report["models"][m] = rep
        if m in open_models:
            own_cells = [cells[f"own|d{d}|N{N}"]["acc"] for d in D_LEVELS for N in N_LEVELS]
            kc[m]["kc1_all_cells_ge90"] = all(a >= KC1_ACC for a in own_cells)
            kc[m]["kc2_gap_lt5"] = g[0] < KC2_GAP
            kc[m]["kc2_slope_ci_includes0"] = rep["d_slope_own"]["lo"] <= 0 <= rep["d_slope_own"]["hi"]
            kc[m]["kc3_flip_lt50"] = rep["flip_rate_d0_N2"]["est"] < KC3_FLIP
            kc[m]["kc4_hint_all_cells_ge90"] = all(v["acc"] >= KC4_ACC for v in rep["hint_cells"].values())
            kc[m]["kc5_gap"] = g[0] >= KC5_GAP and g[1] > 0
            kc[m]["kc5_drop"] = dr[0] >= KC5_DROP and dr[1] > 0
    fired = {
        "KC1_no_phenomenon_KILL": bool(open_models) and all(kc[m]["kc1_all_cells_ge90"] for m in open_models),
        "KC2_not_self_specific_not_dynamic_KILL": bool(open_models) and all(kc[m]["kc2_gap_lt5"] and kc[m]["kc2_slope_ci_includes0"] for m in open_models),
        "KC3_generic_context_blindness_KILL_or_PIVOT": bool(open_models) and all(kc[m]["kc3_flip_lt50"] for m in open_models),
        "KC4_trivial_fix_DOWNGRADE": bool(open_models) and all(kc[m]["kc4_hint_all_cells_ge90"] for m in open_models),
        "KC5_PROCEED": sum(kc[m]["kc5_gap"] or kc[m]["kc5_drop"] for m in open_models) >= 2,
    }
    report["kc_per_model"] = kc
    report["kc_fired"] = fired
    report["n_open_models"] = len(open_models)
    return report

if __name__ == "__main__":
    rep = analyze(sys.argv[1] if len(sys.argv) > 1 else "results.jsonl")
    json.dump(rep, open(sys.argv[2] if len(sys.argv) > 2 else "analysis_report.json", "w"), indent=2)
    print(json.dumps(rep["kc_fired"], indent=2))
    if rep["n_open_models"] != 3:
        print(f"WARNING: preregistration requires 3 open models; found {rep['n_open_models']}.")
