"""Runner: sends every item to every configured model via any OpenAI-compatible
/chat/completions endpoint (Ollama, vLLM, LM Studio, OpenRouter, Together, ...).
No third-party dependencies. Resumable (skips item/model/arm already in results.jsonl).

Usage:
    python owngoal.py                    # writes items.jsonl
    python run_models.py models.json     # writes results.jsonl
Preregistered settings: temperature 0, JSON-only answer, fixed prompt templates (owngoal.py).
"""
import json, os, sys, time, urllib.request
from owngoal import all_items, build_messages

def call(endpoint, model, key, messages, max_tokens, timeout=600):
    body = json.dumps({"model": model, "messages": messages, "temperature": 0,
                       "max_tokens": max_tokens}).encode()
    req = urllib.request.Request(endpoint.rstrip("/") + "/chat/completions", data=body,
                                 headers={"Content-Type": "application/json",
                                          **({"Authorization": f"Bearer {key}"} if key else {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read())["choices"][0]["message"]["content"]

def main(cfg_path, out="results.jsonl"):
    cfg = json.load(open(cfg_path))
    items = all_items()
    done = set()
    if os.path.exists(out):
        for line in open(out):
            r = json.loads(line); done.add((r["model_tag"], r["item_id"], r["arm"]))
    with open(out, "a") as f:
        for m in cfg["models"]:
            key = os.environ.get(m.get("api_key_env", ""), "")
            for it in items:
                if m["role"] == "frontier" and not it["frontier_slice"]:
                    continue
                arms = ["base"] + (["hint"] if (m["role"] == "open" and it["hint_slice"]) else [])
                for arm in arms:
                    tag = (m["tag"], it["item_id"], arm)
                    if tag in done:
                        continue
                    msgs = build_messages(it, hint=(arm == "hint"))
                    for attempt in range(3):
                        try:
                            t0 = time.time()
                            txt = call(m["endpoint"], m["model"], key, msgs, m.get("max_tokens", 1024))
                            break
                        except Exception as e:
                            txt = f"__ERROR__ {e}"; time.sleep(5 * (attempt + 1))
                    f.write(json.dumps({"model_tag": m["tag"], "role": m["role"], "item_id": it["item_id"],
                                        "arm": arm, "raw": txt, "latency_s": round(time.time() - t0, 2)}) + "\n")
                    f.flush()
            print("done", m["tag"])

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "models.json")
