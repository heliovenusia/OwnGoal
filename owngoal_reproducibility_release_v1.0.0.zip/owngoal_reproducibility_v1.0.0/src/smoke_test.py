"""Configuration smoke test. NOT pilot data: dummy prompt, not an item.
Checks connectivity, that the endpoint accepts temperature=0 + max_tokens (as the frozen runner sends),
JSON compliance, and where Qwen3 puts its thinking.
Usage: python smoke_test.py models_deepinfra.json"""
import json, os, sys, urllib.request, urllib.error
cfg = json.load(open(sys.argv[1]))
msgs = [{"role": "system", "content": "You are a test harness."},
        {"role": "user", "content": 'Reply with JSON only, exactly: {"cause": "cannot_determine", "confidence": 50, "action": "hold_and_monitor"}'}]
ok_all = True
for m in cfg["models"]:
    if "<" in m["endpoint"] or "<" in m["model"]:
        print("SKIP", m["tag"], "- slot not filled"); continue
    key = os.environ.get(m["api_key_env"], "")
    if not key:
        print("FAIL", m["tag"], "- env var", m["api_key_env"], "is not set"); ok_all = False; continue
    body = json.dumps({"model": m["model"], "messages": msgs, "temperature": 0, "max_tokens": m.get("max_tokens", 1024)}).encode()
    req = urllib.request.Request(m["endpoint"].rstrip("/") + "/chat/completions", data=body,
          headers={"Content-Type": "application/json", "Authorization": "Bearer " + key})
    try:
        r = json.loads(urllib.request.urlopen(req, timeout=300).read())
    except urllib.error.HTTPError as e:
        print("FAIL", m["tag"], e.code, e.read()[:400]); ok_all = False; continue
    except Exception as e:
        print("FAIL", m["tag"], e); ok_all = False; continue
    msg = r["choices"][0]["message"]; c = msg.get("content") or ""
    print("PASS", m["tag"], "| model echoed:", r.get("model"), "| usage:", r.get("usage"))
    print("     content[:200]:", c[:200].replace("\n", " "))
    print("     <think> in content:", "<think>" in c, "| separate reasoning field:",
          any(k in msg for k in ("reasoning_content", "reasoning")))
print("ALL PASS" if ok_all else "SOME FAILED - fix before running")
