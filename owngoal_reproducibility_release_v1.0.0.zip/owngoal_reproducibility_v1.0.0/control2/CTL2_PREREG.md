# OwnGoal CTL2: final authorship-confound replication: freeze record (2026-10-05, before any model call)

## Repair and invariance
- **Single repair vs ctl/:** every assistant no-action turn, in all four cells, now reads "Step s: I make no u1 change." (was "hold u1 (no change).").
- **Everything else is identical:**
  - generator otherwise unchanged (diff = 1 line + docstring);
  - same 60 situations and 480 item ids;
  - same physics, labels, operator note, reminders, system prompt and question;
  - same models (Qwen3-14B, Mistral-Small-24B on DeepInfra; gpt-4.1-2025-04-14 on the same 48-item 10% slice, descriptive);
  - same runner, parser, estimands and bootstrap (ctl_analyze.py copied byte-identical).

## Validation (before calls)
- **ctl_validate.py: PASS.** 120 quadruplets, 0 problems; ideal observer 1.000.
- **ctl2_conflict_check.py: PASS.**
  - V-CONFLICT: 0 contradictions;
  - 0 assistant turns containing global-state phrases (hold / unchanged / no change / remain / stay / kept / constant);
  - 0 missing operator notes;
  - 0 cross-control differences beyond the repair.

## Frozen decision hierarchy (ctl2_decide.py; must hold in BOTH Qwen and Mistral)
"sig(x, t)" means estimate ≥ t **and** CI lower bound > 0.
- **F1:** sig(C1, 0.10).
- **F2:** sig(Δ_A, 0.10).
- **F3** (not driven solely by OTHER/RECENT): C1 > 0 and C1 ≥ 0.5·C2.
- **K-AUTH:** |C1| < 0.10 or the CI of C1 contains 0.
- **I1:** sig(C4, 0.15). **I2:** C3 < 0.10 or the CI of C3 contains 0.
- **PURE:** sig(C3, 0.10), sig(C4, 0.10), |C4 − C3| < 0.10, and C1, C2 each with |x| < 0.05 and CI ∋ 0.

**Decision order:**
1. F1 ∧ F2 ∧ F3 → AUTHORSHIP MAIN EFFECT RESTORED → FULL ARTICLE CANDIDATE → RETURN TO ORCHESTRATOR.
2. Else (K-AUTH, or a model-inconsistent C1), then:
   - I1 ∧ I2 → INTERACTION SURVIVES → COMPACT ARTICLE CANDIDATE (conditional on belief→action replicating) → COMPACT-PAPER FEASIBILITY AUDIT;
   - else PURE → CONTEXT-INTEGRATION NOTE → CONTEXT-INTEGRATION NOTE FEASIBILITY AUDIT;
   - else → KILL → STOP / KILL.

The hierarchy was plumbing-tested with pseudo-models; all four branches fired as intended.

**Stopping rule:** this is the last authorship-confound control. No further wording, format or model rescue.
