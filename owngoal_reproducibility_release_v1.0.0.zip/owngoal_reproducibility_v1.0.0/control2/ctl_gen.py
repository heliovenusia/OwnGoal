"""[CTL2 REPLICATION: only change vs ctl/ = assistant no-action wording -> 'I make no u1 change.']
OwnGoal confound-resolution control: 2x2 (authorship OWN/OTHER x position EARLIER/RECENT).
Reuses the frozen plant/item generator (../owngoal.py, unchanged). Writes ctl_items.jsonl.

Design (fixed before any model call; see CTL_PREREG.md):
  * Situations: retained core minimal pairs from the frozen pilot, keyed (d, N, k_idx, seed).
    10 per d x N cell (60 total), chosen as the 10 lowest sha256(key) values in each cell.
  * Each situation x cause {own_move, exogenous} x 4 cells -> 480 items per model.
  * All four cells share one dialogue skeleton (step-by-step user readings + assistant decisions).
    Only two things vary:
      - WHO made the move:  OWN   -> the assistant turn at the move step says it made the move;
                            OTHER -> the user turn at the move step reports Operator B's move
                                     (the assistant turn at that step is the standard 'hold').
      - WHETHER a neutral reminder appears in the final message (RECENT) or not (EARLIER).
    For exogenous twins the reminder states that no u1 change was made, in parallel wording.
"""
import json, hashlib, sys, os, collections
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from owngoal import (all_items, retained, SYSTEM, QUESTION, Y_BASE, W, _fmt_table, _step_of,
                     D_LEVELS, N_LEVELS)

PER_CELL = 10
AUTH = ["OWN", "OTHER"]
POS = ["EARLIER", "RECENT"]

def hold_txt(step):
    return f"Step {step}: I make no u1 change."

def own_move_txt(step, s):
    verb = "increase" if s > 0 else "decrease"
    return f"Step {step}: I {verb} u1 by {s:+.1f} t/h to adjust throughput."

def other_note(s):
    verb = "increased" if s > 0 else "decreased"
    return f" Operator B {verb} u1 by {s:+.1f} t/h to adjust throughput at this step."

def reminder(auth, move):
    if move is None:
        who = "you made" if auth == "OWN" else "Operator B made"
        return f"For reference: {who} no u1 changes in this window."
    step, s = move
    verb = "increased" if s > 0 else "decreased"
    who = "you" if auth == "OWN" else "Operator B"
    return f"For reference: at step {step} {who} {verb} u1 by {s:+.1f} t/h to adjust throughput."

def build(it, auth, pos):
    """it: frozen pilot item (any authorship copy; only physics fields are used)."""
    msgs = [{"role": "system", "content": SYSTEM}]
    tp = it["t_probe"]; lo = tp - W + 1
    moves = {t: s for t, s in it["u_steps"]}
    for t in range(lo, tp):
        step = _step_of(it, t)
        utext = f"Step {step}: y2 = {Y_BASE + it['y_obs'][t]:.2f} degC."
        if t in moves and auth == "OTHER":
            utext += other_note(moves[t])
        utext += " State your u1 decision for this step."
        msgs.append({"role": "user", "content": utext})
        if t in moves and auth == "OWN":
            atext = own_move_txt(step, moves[t])
        else:
            atext = hold_txt(step)
        msgs.append({"role": "assistant", "content": atext})
    final = "Full y2 history for the window (the last row is the current step):\n" + _fmt_table(it)
    if pos == "RECENT":
        mv = None if not moves else (_step_of(it, list(moves)[0]), list(moves.values())[0])
        final += "\n\n" + reminder(auth, mv)
    msgs.append({"role": "user", "content": final + "\n\n" + QUESTION})
    return msgs

def select_situations():
    src = [i for i in all_items() if i["kind"] == "core" and i["authorship"] == "neutral_log" and retained(i)]
    sit = collections.defaultdict(dict)
    for i in src:
        sit[(i["d"], i["N"], i["k_idx"], i["seed"])][i["cause"]] = i
    chosen = []
    for d in D_LEVELS:
        for N in N_LEVELS:
            keys = [k for k in sit if k[0] == d and k[1] == N and len(sit[k]) == 2]
            keys.sort(key=lambda k: hashlib.sha256(("ctl|" + "|".join(map(str, k))).encode()).hexdigest())
            assert len(keys) >= PER_CELL, (d, N, len(keys))
            chosen += keys[:PER_CELL]
    return chosen, sit

def make():
    chosen, sit = select_situations()
    out = []
    for key in chosen:
        sid = "s_d{}_N{}_k{}_s{}".format(*key)
        frontier = int(hashlib.sha256(("ctlF|" + sid).encode()).hexdigest()[:8], 16) % 10 == 0
        for cause in ["own_move", "exogenous"]:
            it = sit[key][cause]
            for a in AUTH:
                for p in POS:
                    out.append(dict(item_id=f"{sid}_{cause}_{a}_{p}", situation=sid, cause=cause,
                                    authorship=a, position=p, d=it["d"], N=it["N"], k=it["k"],
                                    seed=it["seed"], T=it["T"], label=it["label"], frontier_slice=frontier,
                                    src_item=it["item_id"], y_obs=it["y_obs"], u_steps=it["u_steps"],
                                    dist_steps=it["dist_steps"], t_probe=it["t_probe"],
                                    messages=build(it, a, p)))
    return out

if __name__ == "__main__":
    items = make()
    with open(os.path.join(os.path.dirname(__file__), "ctl_items.jsonl"), "w") as f:
        for it in items:
            f.write(json.dumps(it) + "\n")
    print(len(items), "control items;", len({i['situation'] for i in items}), "situations;",
          sum(i['frontier_slice'] for i in items), "frontier-slice items")
