"""V-CONFLICT + cross-control identity check (CTL2).
1. Every OTHER own_move item: the user turn at the move step reports Operator B's change, and the
   assistant turn at that step is exactly 'Step s: I make no u1 change.'
2. No assistant message in ANY item asserts a global actuator state ('hold', 'unchanged', 'no change',
   'remain', 'stays', 'kept', 'constant').
3. Versus ctl/ctl_items.jsonl: identical item ids, physics fields, and identical messages except the
   assistant no-action turns (old 'hold u1 (no change).' -> new 'I make no u1 change.').
"""
import json, os, re
H = os.path.dirname(os.path.abspath(__file__))
new = [json.loads(l) for l in open(os.path.join(H, "ctl_items.jsonl"))]
old = {json.loads(l)["item_id"]: json.loads(l) for l in open(os.path.join(H, "..", "ctl", "ctl_items.jsonl"))}
BAN = re.compile(r"\bhold\b|unchanged|\bno change\b|remain|\bstays?\b|\bkept\b|constant", re.I)
conflicts, banned, xdiff, opmiss = [], [], [], []
for it in new:
    msgs = it["messages"]
    for j, m in enumerate(msgs):
        if m["role"] == "assistant" and BAN.search(m["content"]):
            banned.append((it["item_id"], j, m["content"]))
    if it["authorship"] == "OTHER" and it["u_steps"]:
        t0 = it["u_steps"][0][0]; lo = it["t_probe"] - 12 + 1; ui = 1 + 2 * (t0 - lo)
        step = t0 - lo + 1
        if "Operator B" not in msgs[ui]["content"]: opmiss.append(it["item_id"])
        if msgs[ui + 1]["content"] != f"Step {step}: I make no u1 change.": conflicts.append(it["item_id"])
    o = old.get(it["item_id"])
    if o is None: xdiff.append((it["item_id"], "missing in ctl")); continue
    for f in ["y_obs", "u_steps", "dist_steps", "t_probe", "label", "d", "N", "k", "seed", "cause", "authorship", "position", "situation"]:
        if o[f] != it[f]: xdiff.append((it["item_id"], f))
    for a, b in zip(o["messages"], it["messages"]):
        if a != b and not (a["role"] == b["role"] == "assistant" and a["content"].endswith("hold u1 (no change).")
                           and b["content"] == a["content"].replace("hold u1 (no change).", "I make no u1 change.")):
            xdiff.append((it["item_id"], "message")); break
ok = not (conflicts or banned or xdiff or opmiss) and len(new) == len(old)
print(f"items {len(new)} | V-CONFLICT contradictions {len(conflicts)} | banned global-state phrases in assistant turns {len(banned)} "
      f"| OTHER move-step operator note missing {len(opmiss)} | cross-control differences beyond the repair {len(xdiff)}")
for x in (conflicts + banned + xdiff + opmiss)[:5]: print("  ", x)
print("CONFLICT CHECK", "PASS" if ok else "FAIL")
json.dump(dict(contradictions=len(conflicts), banned=len(banned), xdiff=len(xdiff), opmiss=len(opmiss), passed=ok),
          open(os.path.join(H, "ctl2_conflict_check.json"), "w"), indent=2)
