"""CTL2 frozen decision hierarchy (Orchestrator brief sections 11-15, 19, 20.S).
Estimands come from the UNCHANGED ctl_analyze.py (same bootstrap, B=10,000, seed 20261005).
Usage: python ctl2_decide.py ctl_results.jsonl ctl2_report.json"""
import json, os, sys
H = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, H)
from ctl_analyze import analyze

PRIMARY = ["qwen3-14b", "mistral-small-24b"]
def sig(c, t): return c["est"] >= t and c["lo"] > 0
def null10(c): return abs(c["est"]) < 0.10 or (c["lo"] <= 0 <= c["hi"])     # K-AUTH / I2 wording
def nullstrict(c): return abs(c["est"]) < 0.05 and c["lo"] <= 0 <= c["hi"]  # 'null' for pure-position (as in ctl/)

def decide(rep):
    per = {}
    for m in PRIMARY:
        o = rep["models"][m]
        C1, C2, C3, C4, dA = (o["C1_auth_at_EARLIER"], o["C2_auth_at_RECENT"], o["C3_recency_within_OWN"],
                              o["C4_recency_within_OTHER"], o["delta_A"])
        per[m] = dict(
            F1=sig(C1, 0.10), F2=sig(dA, 0.10),
            # F3 (fixed pre-data): not driven solely by OTHER/RECENT -> the EARLIER authorship gap is at least
            # half the RECENT authorship gap (C1 >= 0.5*C2) and C1 itself is positive.
            F3=C1["est"] > 0 and C1["est"] >= 0.5 * C2["est"],
            K_AUTH=null10(C1),
            I1=sig(C4, 0.15), I2=null10(C3) or C3["est"] < 0.10,
            # pure position (fixed pre-data): C3 and C4 both sig at 10 pp, similar (|C4-C3| < 10 pp),
            # and C1, C2 null (|x| < 5 pp with CI containing 0)
            PURE=sig(C3, 0.10) and sig(C4, 0.10) and abs(C4["est"] - C3["est"]) < 0.10 and nullstrict(C1) and nullstrict(C2))
    allm = lambda k: all(per[m][k] for m in PRIMARY)
    if allm("F1") and allm("F2") and allm("F3"):
        rule, ceiling, final = "AUTHORSHIP MAIN EFFECT RESTORED - FULL STUDY RECONSIDERED", "FULL ARTICLE CANDIDATE", "RETURN TO ORCHESTRATOR FOR FULL-STUDY DECISION"
    else:
        kauth = allm("K_AUTH")
        pre = ("K-AUTH: MATCHED-POSITION AUTHORSHIP EFFECT NOT SUPPORTED (OwnGoal main effect permanently withdrawn); "
               if kauth else "AUTHORSHIP MAIN EFFECT NOT ESTABLISHED (model-inconsistent C1; F-path failed); ")
        if allm("I1") and allm("I2"):
            rule, ceiling, final = pre + "INTERACTION SURVIVES", "COMPACT ARTICLE CANDIDATE (if belief->action replicates)", "COMPACT-PAPER FEASIBILITY AUDIT"
        elif allm("PURE"):
            rule, ceiling, final = pre + "PURE RECENCY / CONTEXT-INTEGRATION EFFECT", "CONTEXT-INTEGRATION NOTE", "CONTEXT-INTEGRATION NOTE FEASIBILITY AUDIT"
        else:
            rule, ceiling, final = pre + "NEITHER AUTHORSHIP NOR DIFFERENTIAL INTERACTION SURVIVES", "KILL", "STOP / KILL"
    return dict(per_model=per, rule_fired=rule, ceiling=ceiling, final_decision=final)

if __name__ == "__main__":
    rep = analyze(sys.argv[1] if len(sys.argv) > 1 else os.path.join(H, "ctl_results.jsonl"))
    rep["ctl2_decision"] = decide(rep)
    json.dump(rep, open(sys.argv[2] if len(sys.argv) > 2 else os.path.join(H, "ctl2_report.json"), "w"), indent=2)
    print(json.dumps(rep["ctl2_decision"], indent=2))
