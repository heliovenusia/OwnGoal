import json, os, re, math, collections
import numpy as np
from pathlib import Path
ROOT=Path('/mnt/data/paper3_work/paper 3/owngoal/owngoal_pilot')
SEED=20261005; B=50000; MARGIN=0.10
TARGET={'self_caused_by_earlier_u1_move':'earlier_u1_move','external_disturbance_or_fault':'external_disturbance_or_fault'}
# actual TARGET labels can be imported, but parser below is enough

def parse(raw):
    if raw is None: return None,None,None
    # extract last json object, allowing fenced json
    m=re.search(r'\{[^{}]*"cause"[^{}]*\}', raw, re.S)
    if not m: return None,None,None
    try: o=json.loads(m.group(0))
    except: return None,None,None
    return o.get('cause'),o.get('confidence'),o.get('action')

def ci_boot(x, level=.95):
    x=np.asarray(x,float); n=len(x)
    if n==0:return dict(est=float('nan'),lo=float('nan'),hi=float('nan'),n=0)
    rng=np.random.default_rng(SEED)
    # chunk to keep memory small
    means=[]; remain=B
    while remain:
        k=min(remain,5000)
        idx=rng.integers(0,n,(k,n)); means.append(x[idx].mean(1)); remain-=k
    bs=np.concatenate(means)
    a=(1-level)/2*100
    return dict(est=float(x.mean()),lo=float(np.percentile(bs,a)),hi=float(np.percentile(bs,100-a)),n=n)

def equiv90(x, margin=MARGIN):
    c=ci_boot(x,.90)
    return {**c,'margin':margin,'equivalent': bool(c['lo']>-margin and c['hi']<margin)}

def exact_zero_discordance_bound(n, alpha=.05):
    # if no paired outcomes differ, |marginal difference| <= discordance probability;
    # one-sided CP upper bound for 0 discordances.
    return 1-alpha**(1/n) if n else float('nan')

def load_ctl(sub):
    d=ROOT/sub
    items={json.loads(l)['item_id']:json.loads(l) for l in open(d/'ctl_items.jsonl')}
    rows=[]
    for l in open(d/'ctl_results.jsonl'):
        r=json.loads(l); it=items[r['item_id']]; cause,conf,act=parse(r.get('raw'))
        label=it['label']
        # imported TARGET in source maps label names; inspect by semantic cause from item cause
        truth='earlier_u1_move' if it['cause']=='own_move' else 'external_disturbance_or_fault'
        rows.append(dict(run=sub,model=r['model_tag'],item=r['item_id'],sit=it['situation'],cause_type=it['cause'],a=it['authorship'],p=it['position'],d=it['d'],N=it['N'],pred=cause,conf=conf,act=act,correct=int(cause==truth)))
    return rows

def contrasts(rows, model):
    end=[r for r in rows if r['model']==model and r['cause_type']=='own_move']
    S=collections.defaultdict(dict)
    for r in end:S[r['sit']][(r['a'],r['p'])]=r['correct']
    full=[v for v in S.values() if len(v)==4]
    A=np.array([v[('OWN','EARLIER')] for v in full],float)
    Bc=np.array([v[('OWN','RECENT')] for v in full],float)
    C=np.array([v[('OTHER','EARLIER')] for v in full],float)
    D=np.array([v[('OTHER','RECENT')] for v in full],float)
    arrs={
      'C1_auth_EARLIER':C-A,
      'C2_auth_RECENT':D-Bc,
      'C3_recency_OWN':Bc-A,
      'C4_recency_OTHER':D-C,
      'delta_A':(C+D-A-Bc)/2,
      'delta_P':(Bc+D-A-C)/2,
      'interaction':(C-A)-(D-Bc),
    }
    out={}
    for k,x in arrs.items():
        q={'ci95':ci_boot(x,.95),'equiv90':equiv90(x)}
        if np.all(x==0):q['zero_discordance_abs_effect_95_upper']=exact_zero_discordance_bound(len(x))
        out[k]=q
    cells={}
    for a in ['OWN','OTHER']:
      for p in ['EARLIER','RECENT']:
        x=[r['correct'] for r in end if r['a']==a and r['p']==p]
        cells[f'{a}/{p}']=ci_boot(x,.95)
    return {'n_quad':len(full),'cells':cells,'contrasts':out,'arrays':arrs}

ctl=load_ctl('ctl'); ctl2=load_ctl('ctl2')
models=['qwen3-14b','mistral-small-24b']
rep={'margin':MARGIN,'control1':{},'control2':{},'repair_sensitivity':{}}
for m in models:
    rep['control1'][m]=contrasts(ctl,m)
    rep['control2'][m]=contrasts(ctl2,m)
    # paired across identical situations: change in each contrast from ctl to ctl2
    a=rep['control1'][m]['arrays']; b=rep['control2'][m]['arrays']
    rep['repair_sensitivity'][m]={}
    for k in a:
        diff=b[k]-a[k]
        rep['repair_sensitivity'][m][k]={'ci95':ci_boot(diff,.95),'equiv90':equiv90(diff)}
# remove arrays before serialization
for stage in ['control1','control2']:
  for m in models: rep[stage][m].pop('arrays',None)
# pilot summary from existing analysis_report
pilot=json.load(open(ROOT/'run/analysis_report.json'))
rep['pilot']={m:{'gap_third_minus_own':pilot['models'][m]['gap_third_minus_own'], 'd_slope_own':pilot['models'][m]['d_slope_own']} for m in models}
# action belief conditional pooled within each control
for stage,rows in [('control1',ctl),('control2',ctl2)]:
    for m in models:
        rr=[r for r in rows if r['model']==m and r['cause_type']=='own_move']
        sec={}
        for belief in ['external_disturbance_or_fault','earlier_u1_move']:
            z=[r for r in rr if r['pred']==belief]
            sec[belief]={'n':len(z),'fault_response_rate':sum(r['act']=='fault_response' for r in z)/len(z) if z else None}
        rep[stage][m]['belief_action_pooled']=sec

out=Path('/mnt/data/paper3_work/OWNGOAL_FINAL_NEGATIVE_ANALYSIS.json')
json.dump(rep,open(out,'w'),indent=2)

# canonical csv
import csv
csvp=Path('/mnt/data/paper3_work/owngoal_canonical_results.csv')
with open(csvp,'w',newline='') as f:
    w=csv.writer(f); w.writerow(['stage','model','metric','estimate','ci95_lo','ci95_hi','equiv90_lo','equiv90_hi','equiv_within_10pp'])
    for stage in ['control1','control2']:
      for m in models:
        for k,v in rep[stage][m]['contrasts'].items():
          c=v['ci95']; e=v['equiv90'];w.writerow([stage,m,k,c['est'],c['lo'],c['hi'],e['lo'],e['hi'],e['equivalent']])
    for m in models:
      g=rep['pilot'][m]['gap_third_minus_own'];w.writerow(['pilot',m,'gap_third_minus_own',g['est'],g['lo'],g['hi'],'','',''])
    for m in models:
      for k,v in rep['repair_sensitivity'][m].items():
        c=v['ci95'];e=v['equiv90'];w.writerow(['ctl2_minus_ctl',m,k,c['est'],c['lo'],c['hi'],e['lo'],e['hi'],e['equivalent']])
print(out)
print(csvp)
print(json.dumps(rep['control2'],indent=2)[:12000])
