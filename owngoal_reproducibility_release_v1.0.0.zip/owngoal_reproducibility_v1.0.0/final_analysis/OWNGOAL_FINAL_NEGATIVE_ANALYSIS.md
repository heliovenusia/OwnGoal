# OwnGoal final negative/robustness analysis

Date: 2026-10-05

## Purpose
This analysis uses only the frozen pilot, CTL, and CTL2 outputs. No new model calls were made. The original self-authorship mechanism remains withdrawn. The purpose is to quantify what the controlled experiments do and do not rule out, and to provide one canonical source for manuscript writing.

## Equivalence convention
The project preregistered 10 percentage points as the minimum materially interesting authorship effect. I therefore use ±10 pp as the equivalence margin. For paired contrasts, a 90% matched-bootstrap interval lying fully inside [-10,+10] pp is treated as evidence of practical equivalence. When every paired difference is exactly zero, the nonparametric bootstrap is degenerate; in that case I additionally report the exact one-sided 95% Clopper-Pearson upper bound on the discordance probability. With 0 discordant pairs in n=60, that upper bound is 4.87%, which implies an absolute paired marginal difference below 4.87 pp under the observed matching structure.

## Pilot
The pilot showed large apparent third-party-minus-own gaps:

- Qwen3-14B: +30.8 pp, 95% bootstrap CI +24.6 to +37.1 pp.
- Mistral-Small-24B: +37.5 pp, 95% bootstrap CI +31.3 to +44.2 pp.

These estimates are not interpretable as clean authorship effects because authorship was confounded with conversational presentation/position.

## CTL: first factorial control
At matched EARLIER position:

- Qwen C1 = -3.3 pp, 95% CI -11.7 to +5.0 pp. The 90% equivalence interval is not wholly inside ±10 pp, so this is **inconclusive rather than evidence of equivalence**.
- Mistral C1 = 0 pp with 0/60 discordant matched situations. The exact 95% upper bound on discordance is 4.87%, supporting practical equivalence within ±10 pp for this contrast.

The apparent surviving differential-recency pattern was therefore already model-dependent.

## CTL2: contradiction-free replication
The semantics-preserving no-action wording repair changed the pattern materially.

### Qwen3-14B
- C1 authorship at EARLIER: +16.7 pp, 95% CI +5.0 to +30.0 pp; not equivalent to zero.
- C2 authorship at RECENT: +10.0 pp, 95% CI -5.0 to +25.0 pp; inconclusive.
- C3 recency within OWN: +23.3 pp, 95% CI +10.0 to +36.7 pp.
- C4 recency within OTHER: +16.7 pp, 95% CI +1.7 to +31.7 pp.
- Marginal authorship: +13.3 pp, 95% CI +3.3 to +23.3 pp.
- Marginal position: +20.0 pp, 95% CI +9.2 to +30.8 pp.

Thus Qwen does show a material authorship contrast in CTL2, but this direction and magnitude were not stable across CTL and CTL2.

### Mistral-Small-24B
- C1 authorship at EARLIER: 0 pp, 0/60 discordant pairs; exact 95% discordance upper bound 4.87%. This supports equivalence within ±10 pp.
- C2 authorship at RECENT: +8.3 pp, 95% CI +1.7 to +16.7 pp; the 90% interval extends above +10 pp, so equivalence is not established.
- C3 recency within OWN: 0 pp, 0/60 discordant pairs; exact 95% discordance upper bound 4.87%.
- C4 recency within OTHER: +8.3 pp, 95% CI +1.7 to +16.7 pp.
- Marginal authorship: +4.2 pp, 95% CI +0.8 to +8.3 pp; 90% interval +1.7 to +7.5 pp, within the ±10 pp equivalence margin.
- Marginal position: +4.2 pp, 95% CI +0.8 to +8.3 pp; likewise practically small by the preregistered 10 pp threshold.

Mistral therefore does not reproduce Qwen's CTL2 authorship pattern.

## Sensitivity to the one-phrase repair
Because CTL and CTL2 use the same matched situations and differ only in the repaired no-action wording, their contrast changes can be paired directly.

The central result is not that one specific effect becomes zero. It is that the estimated mechanism changes materially under a semantics-preserving presentation repair:

- Qwen C1 moves from -3.3 pp in CTL to +16.7 pp in CTL2, a +20 pp change.
- Qwen's own-recency contrast moves from +6.7 pp to +23.3 pp.
- Mistral's OTHER-recency contrast moves from +23.3 pp to +8.3 pp.
- Mistral's OTHER/RECENT accuracy falls from 23% to 8%.

The originally proposed stable self-authorship mechanism and the later authorship-by-recency interaction therefore fail the cross-control robustness requirement.

## What can be said statistically
The correct conclusion is **not** that every authorship effect is proven absent. Qwen CTL2 contains a positive matched authorship contrast. The stronger and defensible conclusion is:

> The direction, magnitude, and model consistency of the candidate authorship mechanism are not robust to progressively tighter controls and a semantics-preserving wording repair. A large pilot effect cannot be interpreted as a stable self-authorship mechanism.

For Mistral, CTL2 provides positive evidence that the marginal authorship effect is smaller than the project's 10 pp materiality threshold, while Qwen does not. This model disagreement is itself incompatible with the preregistered full-mechanism claim.

## Belief-to-action association
Across endogenous CTL2 items:

- Qwen: fault-response rate = 59.9% when the model labels the cause external, versus 1.6% when it labels the prior move causal.
- Mistral: fault-response rate = 98.9% after an external-cause belief, versus 0% after a move-caused belief.

This is a robust conditional association in the observed outputs. It should not be rewritten as a claim that external misattribution itself occurs at a stable high rate across models and prompts.

## Final publication-level interpretation
### Supported
1. A large apparent pilot authorship effect was substantially altered after explicit position matching.
2. A residual interaction seen in CTL did not remain stable after a semantics-preserving contradiction repair.
3. Mechanistic conclusions differ materially across Qwen and Mistral under the final controlled design.
4. Cause belief is strongly associated with downstream fault-response recommendations.
5. The full preregistered sequence provides a concrete engineering-agent case study of why single-presentation effect estimates are unsafe as evidence of stable LLM behavioural mechanisms.

### Withdrawn
1. LLM supervisors systematically discount their own prior actions.
2. The pilot's 31-38 pp gap is an authorship effect.
3. Own-action misattribution increases with dead time.
4. A stable authorship x recency interaction exists.
5. All tested models generally default to external-fault attribution.

## Science status
**NEGATIVE/ROBUSTNESS PAPER READY.**

No additional model calls are justified. Manuscript claims should be drawn from `owngoal_canonical_results.csv` and this report, with the original preregistration and reports retained as provenance.
