# Archive errata and interpretation notes

1. In `final_analysis/OWNGOAL_FINAL_NEGATIVE_ANALYSIS.md`, the Qwen control-1 C1 95% lower confidence bound was described once as -11.7 percentage points. The canonical 95% lower bound is -13.3 percentage points; -11.7 percentage points is the corresponding 90% lower bound. `final_analysis/canonical_results.csv` contains the canonical values.
2. The final publication interpretation does not treat Mistral's zero earlier-position contrast as evidence that authorship has no effect. Mistral was floor-limited in that contrast.
3. The plus/minus 10 percentage-point equivalence margin has pre-specified materiality ancestry but was selected retrospectively for the final equivalence analysis; the pre-specified 5 percentage-point null-region ancestry should also be considered.
4. `control1` contains contradictory wording in its OTHER cells. It is retained for provenance and should not be treated as a clean factorial estimate of authorship.
5. `control2` is the corrected factorial control; calling it a literal replication would be misleading.
6. Historical reports are retained for chronology. Where their provisional interpretation differs from `FINAL_SCIENCE_NOTE.md`, the final note controls the publication interpretation.
