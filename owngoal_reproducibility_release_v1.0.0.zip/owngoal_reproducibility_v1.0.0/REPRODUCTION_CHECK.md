# Reproduction check

Public-release verification performed from the archive root with no API keys and no network access.

- `python offline_analysis.py` completed successfully.
- The regenerated canonical CSV was byte-identical to `final_analysis/canonical_results.csv`.
- Reference SHA-256: `3da9ecf91f0fdbe06fd893e1652a05747440a47ac9608c663fbe5423686101be`.
- Archived raw model outputs were not modified.
- Exact future hosted-model reruns are not required for manuscript reproduction and may differ because provider deployments can change.
