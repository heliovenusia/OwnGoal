from pathlib import Path
import json, re, collections, csv, hashlib
import numpy as np

ROOT = Path(__file__).resolve().parent
SEED=20261005; B=50000; MARGIN=0.10

def parse(raw):
    if raw is None: return None,None,None
    m=re.search(r'\{[^{}]*"cause"[^{}]*\}', raw, re.S)
    if not m: return None,None,None
    try: o=json.loads(m.group(0))
    except Exception: return None,None,None
    return o.get('cause'),o.get('confidence'),o.get('action')

def ci_boot(x, level=.95):
    x=np.asarray(x,float); n=len(x)
    if n==0:return dict(est=float('nan'),lo=float('nan'),hi=float('nan'),n=0)
    rng=np.random.default_rng(SEED); means=[]; remain=B
    while remain:
        k=min(remain,5000); idx=rng.integers(0,n,(k,n)); means.append(x[idx].mean(1)); remain-=k
    bs=np.concatenate(means); a=(1-level)/2*100
    return dict(est=float(x.mean()),lo=float(np.percentile(bs,a)),hi=float(np.percentile(bs,100-a)),n=n)

def equiv90(x, margin=MARGIN):
    c=ci_boot(x,.90); return {**c,'margin':margin,'equivalent': bool(c['lo']>-margin and c['hi']<margin)}

def load_ctl(folder, stem):
    d=ROOT/folder
    items={json.loads(l)['item_id']:json.loads(l) for l in open(d/f'{stem}_items.jsonl',encoding='utf-8')}
    rows=[]
    for l in open(d/f'{stem}_results.jsonl',encoding='utf-8'):
        r=json.loads(l); it=items[r['item_id']]; cause,conf,act=parse(r.get('raw'))
        truth='earlier_u1_move' if it['cause']=='own_move' else 'external_disturbance_or_fault'
        rows.append(dict(model=r['model_tag'],sit=it['situation'],cause_type=it['cause'],a=it['authorship'],p=it['position'],pred=cause,correct=int(cause==truth)))
    return rows

def contrasts(rows, model):
    end=[r for r in rows if r['model']==model and r['cause_type']=='own_move']
    S=collections.defaultdict(dict)
    for r in end:S[r['sit']][(r['a'],r['p'])]=r['correct']
    full=[v for v in S.values() if len(v)==4]
    A=np.array([v[('OWN','EARLIER')] for v in full],float); Bc=np.array([v[('OWN','RECENT')] for v in full],float)
    C=np.array([v[('OTHER','EARLIER')] for v in full],float); D=np.array([v[('OTHER','RECENT')] for v in full],float)
    arrs={'C1_auth_EARLIER':C-A,'C2_auth_RECENT':D-Bc,'C3_recency_OWN':Bc-A,'C4_recency_OTHER':D-C,
          'delta_A':(C+D-A-Bc)/2,'delta_P':(Bc+D-A-C)/2,'interaction':(C-A)-(D-Bc)}
    return arrs

ctl=load_ctl('control1','ctl'); ctl2=load_ctl('control2','ctl'); models=['qwen3-14b','mistral-small-24b']
rows=[]
for stage,data in [('control1',ctl),('control2',ctl2)]:
    for m in models:
        for k,x in contrasts(data,m).items():
            c=ci_boot(x,.95); e=equiv90(x)
            rows.append([stage,m,k,c['est'],c['lo'],c['hi'],e['lo'],e['hi'],e['equivalent']])
pilot=json.load(open(ROOT/'pilot/analysis_report.json',encoding='utf-8'))
for m in models:
    g=pilot['models'][m]['gap_third_minus_own']; rows.append(['pilot',m,'gap_third_minus_own',g['est'],g['lo'],g['hi'],'','',''])
for m in models:
    a=contrasts(ctl,m); b=contrasts(ctl2,m)
    for k in a:
        x=b[k]-a[k]; c=ci_boot(x,.95); e=equiv90(x)
        rows.append(['ctl2_minus_ctl',m,k,c['est'],c['lo'],c['hi'],e['lo'],e['hi'],e['equivalent']])
out=ROOT/'reproduced_canonical_results.csv'
with open(out,'w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['stage','model','metric','estimate','ci95_lo','ci95_hi','equiv90_lo','equiv90_hi','equiv_within_10pp']); w.writerows(rows)
ref=ROOT/'final_analysis/canonical_results.csv'
def h(p): return hashlib.sha256(p.read_bytes()).hexdigest()
print('reproduced:',out)
print('canonical_byte_match:', h(out)==h(ref))
print('reference_sha256:',h(ref))
print('reproduced_sha256:',h(out))
